# !/bin/sh

set -e -u

BUILD=0
TEST=0
CLEAN=0
STRICT=0
PACK=0
PULL=0

DEBUG=0
RELEASE=0
VERBOSE=0

show_help() {
  echo "Usage: $(basename $0) <--release|--debug> [--clean] [--test] [--strict] [--pack <package-name>] [--pull] [--verbose|-v]"
}

if [ ! -r "CMakeLists.txt" ]; then
  echo "Could not find CMakeLists.txt - Are you running the script from the root of the project?"
  exit 1
fi

if [ $# -eq 0 ]; then
  show_help
  exit 1
fi

while [ -n "$*" ]; do
  case $1 in
    --debug)
      DEBUG=1
      BUILD=1
      ;;

    --release)
      RELEASE=1
      BUILD=1
      ;;

    --clean)
      CLEAN=1
      ;;

    --strict)
      STRICT=1
      ;;

    --test)
      TEST=1
      ;;

    --verbose|-v)
      VERBOSE=1
      ;;
      
    --pack)
      shift

      if [ -z "${1-}" ]; then
        echo "Missing argument for --pack"
        exit 1
      fi

      PACK=1
      PACKAGE_NAME=$1
      ;;

    --pull)
      PULL=1
      ;;

    --help|-h)
      show_help
      exit 0
      ;;

    *)
      echo "Unknown parameter: $1"
      exit 1
      ;;
  esac

  shift
done

if [ ${BUILD} -eq 0 ] && [ ${TEST} -eq 0 ]; then
  echo $HELP_STRING
  exit 0
fi

if [ ${BUILD} -eq 1 ] && [ ${DEBUG} -eq 1 ] && [ ${RELEASE} -eq 1 ]; then
  echo "Build configuration should be either --debug or --release but not both"
  exit 1
elif [ ${DEBUG} -eq 1 ]; then
  BUILD_TYPE=DEBUG
elif [ ${RELEASE} -eq 1 ]; then
  BUILD_TYPE=RELEASE
fi

if [ ${BUILD} -eq 1 ]; then
  cmake -G "Unix Makefiles" -B build/Customer-linux64-${BUILD_TYPE-""} -S src/Customer -DCMAKE_BUILD_TYPE=${BUILD_TYPE-""} -DSTRICT=${STRICT} -DPACKAGE_NAME=${PACKAGE_NAME-""} $([ ${PULL} -eq 1 ] && echo "-DPULL_VOLTSCRIPT=TRUE")
  cmake --build build/Customer-linux64-${BUILD_TYPE-""} -j 8 $([ ${CLEAN} -eq 1 ] && echo "--clean-first") $([ ${VERBOSE} -eq 1 ] && echo "-v")
  cmake --install build/Customer-linux64-${BUILD_TYPE-""} $([ ${VERBOSE} -eq 1 ] && echo "-v")
fi

if [ ${PACK} -eq 1 ]; then
  cmake --build build/Customer-linux64-${BUILD_TYPE-""} --target pack
fi

if [ ${TEST} -eq 1 ]; then
  # Assume RELEASE build if not specified
  if [ -z "${BUILD_TYPE+null}" ]; then
    BUILD_TYPE=RELEASE
  fi
  if [ $BUILD_TYPE = "DEBUG" ]; then
    LIB_POSTFIX=-D
  fi

  echo "Contents of seti.ini:"
  cat bin/linux64/seti${LIB_POSTFIX-""}.ini

  # If we pulled VoltScript, run the copy we just downloaded.
  if [ ${PULL} -eq 1 ]; then
    export PATH=$(pwd)/bin/VoltScript:${PATH}
  fi
  echo "VoltScript version: $(VoltScript --version)"
  # Run unit tests in tests directory
  echo "Running unit tests for ${BUILD_TYPE} build..."
  echo "Unit tests have not been developed yet."
  # (VoltScript -v --seti bin/linux64/seti${LIB_POSTFIX-""}.ini test/VoltScript/CustomerUnit.vss)
fi
