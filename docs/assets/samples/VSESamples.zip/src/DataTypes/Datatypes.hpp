/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: Datatypes.hpp

   Description:
      Class definition for scriptable "Datatypes" object

\*==============================================================================*/
#if !defined (DATATYPES_HPP)
#define DATATYPES_HPP

//{{LSX_AUTHOR_CODE_Include1
//}}

#include "lsxapplx.h"
#include "lsxbase.hpp"
#include "lsxsess.hpp"

class Datatypes;

typedef LSXObjectArray<Datatypes, CDATATYPES_DATATYPES_ID> DatatypesArray;

//{{LSX_AUTHOR_CODE_Include2
//}}

// forward references to other classes


class Datatypes : public LSXBase
//{{LSX_AUTHOR_CODE_Additional_Base_Classes
//}}
{
   protected:

      // Data members exposed to LotusScript via Get/Set Prop (access functions inlined below)
      LSXBool m_ABoolean;
      LSsCurrency m_ACurrency;
      LSXCurrencyArray m_ACurrencyArray;
      LSXDate m_ADate;
      LSXDateArray m_ADateArray;
      LSSLONG m_ALong;
      LSXLongArray m_ALongArray;
      LSPTR(Datatypes) m_AnObject;
      DatatypesArray m_AnObjectArray;
      LSSSHORT m_AShort;
      LSFLOAT4 m_ASingle;
      LSXString m_AString;
      LSXStringArray m_AStringArray;
      PLSVALUE m_AVariant;

      //{{LSX_AUTHOR_CODE_Protected_Internal
      //}}

   private:

      //{{LSX_AUTHOR_CODE_Private_Internal
      //}}

      // These are private because they are unimplemented and we need to prevent
      // the compiler from creating default versions.
      Datatypes & operator = (Datatypes&);
      Datatypes (const Datatypes&);
      Datatypes();

   public:

      // This constructor is called when the script "new"s one or calls
      // a function like "CreateDatatypes" on the container class.
      Datatypes( LSPTR(LSXLsiSession) pContainer, LSSSHORT theIntArg , LSSLONG theLongArg , LSFLOAT4 theSingleArg , LSXString theStringArg );

      // This constructor is used by a derived class to initialize its parent
      Datatypes(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer, LSSSHORT theIntArg , LSSLONG theLongArg , LSFLOAT4 theSingleArg , LSXString theStringArg  );

      virtual ~Datatypes();


      // Methods exposed to LotusScript
      LSXBool BooleanDemoFunction ( LSXBool ByValArg , LSXBool& ByRefArg  );
      LSXCurrencyArray CurrencyArrayDemoFunction ( LSXCurrencyArray& InputArray  );
      LSsCurrency CurrencyDemoFunction ( LSsCurrency theByvalArg , LSsCurrency& theByrefArg  );
      LSXDateArray DateArrayDemoFunction ( LSXDateArray& InputArray  );
      LSXDate DateDemoFunction ( LSXDate the1stDate , LSXDate& the2ndDate  );
      LSXShortArray MultiDimArrayDemoFunction ( LSXShortArray& InputArray  );
      LSXLongArray NumberArrayDemoFunction ( LSXLongArray& InputArray  );
      LSSLONG NumberDemoFunction ( LSSSHORT Arg1 , LSSLONG& Arg2  );
      DatatypesArray ObjectArrayDemoFunction ( DatatypesArray& InputArray  );
      Datatypes& ObjectDemoFunction ( const Datatypes& theConstRefObj , Datatypes& theRefObj  );
      void RaisingEventsDemoMethod (  );
      LSXStringArray StringArrayDemoFunction ( LSXStringArray& InputArray  );
      LSXString StringDemoFunction ( LSXString Arg1 , LSXString& Arg2  );
      void VariantDemoMethod ( PLSVALUE Arg1  );

      // Event-Raising methods
      void LSXRaiseEvent_NumberArgsDemoEvent ( LSSLONG theByvalArg , LSSLONG& theByrefArg  );
      void LSXRaiseEvent_ObjectArgDemoEvent ( Datatypes& ObjArg  );
      void LSXRaiseEvent_StringArgsDemoEvent ( LSXString theByvalArg , LSXString& theByrefArg  );
      
      // Helper functions - not exposed to LotusScript

      LSPTR(LSXLsiSession) LSXGetSession() const
      { 
         return ((LSPTR(LSXLsiSession)) pContainerObject)->LSXGetSession(); 
      }

      //{{LSX_AUTHOR_CODE_Public_Internal (not exposed to LotusScript)
      //}}

      // Low-level calls defined in iDatatypes.CPP.
      virtual LSSTATUS LSXDispatchMethod(PLSADTMSGMETHOD args);
      virtual LSSTATUS LSXGetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);
      virtual LSSTATUS LSXSetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);


      // Property Gets and Sets for data members exposed to LotusScript
      inline LSXBool GetABoolean() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_ABoolean
         //}}

         return m_ABoolean;
      }
      inline void SetABoolean(const LSXBool ABoolean)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_ABoolean
         //}}
         m_ABoolean = ABoolean;
      }

      inline const LSsCurrency& GetACurrency() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_ACurrency
         //}}

         return m_ACurrency;
      }
      inline void SetACurrency(const LSsCurrency& ACurrency)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_ACurrency
         //}}
         m_ACurrency = ACurrency;
      }

      inline const LSXCurrencyArray& GetACurrencyArray() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_ACurrencyArray
         //}}

         return m_ACurrencyArray;
      }
      inline void SetACurrencyArray(const LSXCurrencyArray& ACurrencyArray)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_ACurrencyArray
         //}}
         m_ACurrencyArray = ACurrencyArray;
      }

      inline const LSXDate& GetADate() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_ADate
         //}}

         return m_ADate;
      }
      inline void SetADate(const LSXDate& ADate)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_ADate
         //}}
         m_ADate = ADate;
      }

      inline const LSXDateArray& GetADateArray() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_ADateArray
         //}}

         return m_ADateArray;
      }
      inline void SetADateArray(const LSXDateArray& ADateArray)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_ADateArray
         //}}
         m_ADateArray = ADateArray;
      }

      inline LSSLONG GetALong() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_ALong
         //}}

         return m_ALong;
      }
      inline void SetALong(const LSSLONG ALong)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_ALong
         //}}
         m_ALong = ALong;
      }

      inline const LSXLongArray& GetALongArray() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_ALongArray
         //}}

         return m_ALongArray;
      }
      inline void SetALongArray(const LSXLongArray& ALongArray)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_ALongArray
         //}}
         m_ALongArray = ALongArray;
      }

      inline Datatypes& GetAnObject()  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_AnObject
         //}}
         if (! m_AnObject)
            LsiInst->RaiseError(LSTID_CURRENT, LSI_RTE_ObjectVariableNotSet, LSNULL, LSI_REGNAME_UNICODE);

         return *m_AnObject;
      }
      inline void SetAnObject(Datatypes& AnObject)
      {
         //You must do reference counting whenever you maintain a
         //reference to an object that LS knows about.  Otherwise
         //it will get deleted when LS is done with it, even if you aren't.
      
         //{{LSX_AUTHOR_CODE_PropertySet_AnObject
         //}}
         if (m_AnObject)
            m_AnObject->DropRef();
         m_AnObject = &AnObject;
         m_AnObject->AddRef();
      }

      inline DatatypesArray& GetAnObjectArray()  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_AnObjectArray
         //}}

         return m_AnObjectArray;
      }
      inline void SetAnObjectArray(const DatatypesArray& AnObjectArray)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_AnObjectArray
         //}}
         m_AnObjectArray = AnObjectArray;
      }

      inline LSSSHORT GetAShort() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_AShort
         //}}

         return m_AShort;
      }
      inline void SetAShort(const LSSSHORT AShort)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_AShort
         //}}
         m_AShort = AShort;
      }

      inline LSFLOAT4 GetASingle() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_ASingle
         //}}

         return m_ASingle;
      }
      inline void SetASingle(const LSFLOAT4 ASingle)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_ASingle
         //}}
         m_ASingle = ASingle;
      }

      inline const LSXString& GetAString() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_AString
         //}}

         return m_AString;
      }
      inline void SetAString(const LSXString& AString)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_AString
         //}}
         m_AString = AString;
      }

      inline const LSXStringArray& GetAStringArray() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_AStringArray
         //}}

         return m_AStringArray;
      }
      inline void SetAStringArray(const LSXStringArray& AStringArray)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_AStringArray
         //}}
         m_AStringArray = AStringArray;
      }

      inline PLSVALUE GetAVariant() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_AVariant
         //}}

         return m_AVariant;
      }
      inline void SetAVariant(const PLSVALUE AVariant)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_AVariant
         //}}
         m_AVariant = AVariant;
      }

      //{{LSX_AUTHOR_CODE_Inlines
      //}}
};

//{{LSX_AUTHOR_CODE_Other
//}}

#endif   //   #if !defined (DATATYPES_HPP)

