/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: iDatatypes.cpp

   Description:
      Class methods to support LSX architecture.

\*============================================================================*/

#include "Datatypes.hpp"



#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 *   Expanded class support (only if this class is expanded)
 *
 *******************************************************************************/

/*******************************************************************************
 *
 *   Containment support (only if this class is a container)
 *
 *******************************************************************************/

/*******************************************************************************
 *
 *   Collection support (only if this class is a collection)
 *
 *******************************************************************************/

/*******************************************************************************
 *
 *   Property Dispatching
 *
 *******************************************************************************/

LSSTATUS Datatypes:: LSXGetProp(PLSADTINSTDESC pInstDesc, PLSADTMSGPROP param)
{
   LSSTATUS     stat = LSX_OK;
   LSADTPROPID  id   = param->idProp;

   LSXValue Val(param->valProp, LsiInst);

   switch (id)
   {
   case CDATATYPES_DATATYPESPROP_ABOOLEAN:
      Val.set(GetABoolean());
      break;

   case CDATATYPES_DATATYPESPROP_ACURRENCY:
      Val.set(GetACurrency());
      break;

   case CDATATYPES_DATATYPESPROP_ACURRENCYARRAY:
      Val.set(GetACurrencyArray());
      break;

   case CDATATYPES_DATATYPESPROP_ADATE:
      Val.set(GetADate());
      break;

   case CDATATYPES_DATATYPESPROP_ADATEARRAY:
      Val.set(GetADateArray());
      break;

   case CDATATYPES_DATATYPESPROP_ALONG:
      Val.set(GetALong());
      break;

   case CDATATYPES_DATATYPESPROP_ALONGARRAY:
      Val.set(GetALongArray());
      break;

   case CDATATYPES_DATATYPESPROP_ANOBJECT:
      Val.set(GetAnObject());
      break;

   case CDATATYPES_DATATYPESPROP_ANOBJECTARRAY:
      Val.set(GetAnObjectArray());
      break;

   case CDATATYPES_DATATYPESPROP_ASHORT:
      Val.set(GetAShort());
      break;

   case CDATATYPES_DATATYPESPROP_ASINGLE:
      Val.set(GetASingle());
      break;

   case CDATATYPES_DATATYPESPROP_ASTRING:
      Val.set(GetAString());
      break;

   case CDATATYPES_DATATYPESPROP_ASTRINGARRAY:
      Val.set(GetAStringArray());
      break;

   case CDATATYPES_DATATYPESPROP_AVARIANT:
      Val.set(GetAVariant());
      break;

   default:
      stat = LSI_ERR_UNAVAIL;
      assert(LSFALSE);
      break;
   }

   return stat;
}

//------------------------------------------------------------------------------

LSSTATUS Datatypes:: LSXSetProp(PLSADTINSTDESC pInstDesc, PLSADTMSGPROP param)
{
   LSSTATUS     stat = LSX_OK;
   LSADTPROPID  id   = param->idProp;

   LSXValue Val(param->valProp, LsiInst);

   switch (id)
   {
   case CDATATYPES_DATATYPESPROP_ABOOLEAN:
      SetABoolean(Val.getBool());
      break;

   case CDATATYPES_DATATYPESPROP_ACURRENCY:
      SetACurrency(Val.getCurrency());
      break;

   case CDATATYPES_DATATYPESPROP_ACURRENCYARRAY:
      SetACurrencyArray(Val.getCurrencyArray());
      break;

   case CDATATYPES_DATATYPESPROP_ADATE:
      SetADate(Val.getDate());
      break;

   case CDATATYPES_DATATYPESPROP_ADATEARRAY:
      SetADateArray(Val.getDateArray());
      break;

   case CDATATYPES_DATATYPESPROP_ALONG:
      SetALong(Val.getLong());
      break;

   case CDATATYPES_DATATYPESPROP_ALONGARRAY:
      SetALongArray(Val.getLongArray());
      break;

   case CDATATYPES_DATATYPESPROP_ANOBJECT:
      SetAnObject((Datatypes&) Val.getADTObject());
      break;

   case CDATATYPES_DATATYPESPROP_ANOBJECTARRAY:
      SetAnObjectArray(Val.getObjectArray(CDATATYPES_DATATYPES_ID));
      break;

   case CDATATYPES_DATATYPESPROP_ASHORT:
      SetAShort(Val.getShort());
      break;

   case CDATATYPES_DATATYPESPROP_ASINGLE:
      SetASingle(Val.getSingle());
      break;

   case CDATATYPES_DATATYPESPROP_ASTRING:
      SetAString(Val.getString());
      break;

   case CDATATYPES_DATATYPESPROP_ASTRINGARRAY:
      SetAStringArray(Val.getStringArray());
      break;

   case CDATATYPES_DATATYPESPROP_AVARIANT:
      SetAVariant(Val.getVariant());
      break;

   default:
      stat = LSI_ERR_UNAVAIL;
      assert(LSFALSE);
      break;
   }

   return stat;
}

/*******************************************************************************
 *
 *   Method Dispatching and Argument Parsing
 *
 *******************************************************************************/
LSSTATUS Datatypes:: LSXDispatchMethod(PLSADTMSGMETHOD args)
{
   LSSTATUS stat = LSX_OK;

   // using the given method id, call the appropriate class method

   switch (args->idMeth)
   {
   case CDATATYPES_DATATYPESMETHOD_BOOLEANDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXBool ByValArg =  ArgList.getArg(1).getBool();
      LSXBool ByRefArg =  ArgList.getArg(2).getBool();

      
      //Execute the method
      LSXBool RetVal = BooleanDemoFunction(ByValArg, ByRefArg);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(2, ByRefArg);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_CURRENCYARRAYDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXCurrencyArray InputArray =  ArgList.getArg(1).getCurrencyArray();

      
      //Execute the method
      LSXCurrencyArray RetVal = CurrencyArrayDemoFunction(InputArray);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(1, InputArray);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_CURRENCYDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSsCurrency theByvalArg =  ArgList.getArg(1).getCurrency();
      LSsCurrency theByrefArg =  ArgList.getArg(2).getCurrency();

      
      //Execute the method
      LSsCurrency RetVal = CurrencyDemoFunction(theByvalArg, theByrefArg);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(2, theByrefArg);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_DATEARRAYDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXDateArray InputArray =  ArgList.getArg(1).getDateArray();

      
      //Execute the method
      LSXDateArray RetVal = DateArrayDemoFunction(InputArray);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(1, InputArray);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_DATEDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXDate the1stDate =  ArgList.getArg(1).getDate();
      LSXDate the2ndDate =  ArgList.getArg(2).getDate();

      
      //Execute the method
      LSXDate RetVal = DateDemoFunction(the1stDate, the2ndDate);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(2, the2ndDate);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_MULTIDIMARRAYDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXShortArray InputArray =  ArgList.getArg(1).getShortArray();

      
      //Execute the method
      LSXShortArray RetVal = MultiDimArrayDemoFunction(InputArray);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(1, InputArray);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_NUMBERARRAYDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXLongArray InputArray =  ArgList.getArg(1).getLongArray();

      
      //Execute the method
      LSXLongArray RetVal = NumberArrayDemoFunction(InputArray);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(1, InputArray);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_NUMBERDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSSSHORT Arg1 =  ArgList.getArg(1).getShort();
      LSSLONG Arg2 =  ArgList.getArg(2).getLong();

      
      //Execute the method
      LSSLONG RetVal = NumberDemoFunction(Arg1, Arg2);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(2, Arg2);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_OBJECTARRAYDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      DatatypesArray InputArray =  ArgList.getArg(1).getObjectArray(CDATATYPES_DATATYPES_ID);

      
      //Execute the method
      DatatypesArray RetVal = ObjectArrayDemoFunction(InputArray);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(1, InputArray);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_OBJECTDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      Datatypes& theConstRefObj =  (Datatypes&) ArgList.getArg(1).getADTObject();
      Datatypes& theRefObj =  (Datatypes&) ArgList.getArg(2).getADTObject();

      
      //Execute the method
      Datatypes& RetVal = ObjectDemoFunction(theConstRefObj, theRefObj);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_RAISINGEVENTSDEMOMETHOD:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, SUB, LsiInst);

      
      
      //Execute the method
      RaisingEventsDemoMethod();
      
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_STRINGARRAYDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXStringArray InputArray =  ArgList.getArg(1).getStringArray();

      
      //Execute the method
      LSXStringArray RetVal = StringArrayDemoFunction(InputArray);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(1, InputArray);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_STRINGDEMOFUNCTION:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXString Arg1 =  ArgList.getArg(1).getString();
      LSXString Arg2 =  ArgList.getArg(2).getString();

      
      //Execute the method
      LSXString RetVal = StringDemoFunction(Arg1, Arg2);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(2, Arg2);
      }
      break;

   case CDATATYPES_DATATYPESMETHOD_VARIANTDEMOMETHOD:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, SUB, LsiInst);

      
      //Extract the arguments
      PLSVALUE Arg1 =  ArgList.getArg(1).getVariant();

      
      //Execute the method
      VariantDemoMethod(Arg1);
      
      }
      break;


   // list any other methods that you are exposing to the users of your LSX

   default:
      /*
      ** Either we have been passed
      **    (i) a bogus method id from LS, or,
      **   (ii) the method id of one of the parent class's methods (ie. this
      **        class is derived from a parent class).
      **
      ** If situation (i) then we need to determine why we have been passed
      ** the bad method id and fix the problem. This could occur if we changed
      ** the id's that we register with LS and did not tell LS at registration
      ** time that they had changed - by updating the version number.
      ** If you have changed the id's  you MUST recompile the script.
      **
      ** In that case, we should fail, thus:

         stat = LSI_RTE_SubOrFunctionNotDefined;
         assert (LSFALSE);

      ** If situation (ii) then we need to pass the method id on to the
      ** parent class dispatch method.  If the parent class is one of
      ** your own classes, you can code the call thus:

         stat = Datatypes::LSXDispatchMethod(args);

      ** If the parent class is one of the Notes back-end classes, then
      ** we need to pass the method id and args block on to his dispatch
      ** method. ie. pretend we are LotusScript.

         stat = pADT->ClassControl(this->LSXGetInstance(),
                                  LSI_ADTMSG_METHOD,
                                  this->LSXGetADTInstDesc(),
                                  (LSPTR(void))args);

      ** In order to use this call successfully, we will need to have cached
      ** a pointer to the "real" corresponding Notes back-end object.
      ** For an example of how this is done, see the LSXBEPlus sample
      ** (NotesDbPlus.CPP & iNotesDbPlus.CPP)
      */

      stat = LSI_RTE_SubOrFunctionNotDefined;
      assert (LSFALSE);
      break;
   }

   return stat;
}
/*******************************************************************************
 *
 *   Event Raising Method Definitions
 *
 *******************************************************************************/
void Datatypes::LSXRaiseEvent_NumberArgsDemoEvent(LSSLONG theByvalArg, LSSLONG& theByrefArg)
{
   LSVALUE Args[N_DATATYPES_NUMBERARGSDEMOEVENT_ARGS];

   LSXValue EventtheByvalArg((LSVALTYPE)LSVT_LONG, LsiInst);
   EventtheByvalArg.set(theByvalArg);
   Args[0] = *( (PLSVALUE)EventtheByvalArg );

   LSXValue EventtheByrefArg((LSVALTYPE)LSVT_LONG|LSVT_BYREF, LsiInst);
   EventtheByrefArg.set(theByrefArg);
   Args[1] = *( (PLSVALUE)EventtheByrefArg );



   LSICALL(RaiseEvent(this->GetInterfacePtr(), CDATATYPES_DATATYPESEVENT_NUMBERARGSDEMOEVENT,
                      (LSUSHORT)N_DATATYPES_NUMBERARGSDEMOEVENT_ARGS, Args,
                      LSIR_EVM_INTERRUPT, LSIR_EVX_COMPLETE));

   //Set the byref args here
   LSXArgs ArgList(Args, N_DATATYPES_NUMBERARGSDEMOEVENT_ARGS, LsiInst);
   theByrefArg =  ArgList.getArg(2).getLong();
}
// -----------------------------------------------------------------------------
void Datatypes::LSXRaiseEvent_ObjectArgDemoEvent(Datatypes& ObjArg)
{
   LSVALUE Args[N_DATATYPES_OBJECTARGDEMOEVENT_ARGS];

   LSXValue EventObjArg((LSVALTYPE)LSX_CLASS_ARG(CDATATYPES_DATATYPES_ID), LsiInst);
   EventObjArg.set(ObjArg);
   Args[0] = *( (PLSVALUE)EventObjArg );



   LSICALL(RaiseEvent(this->GetInterfacePtr(), CDATATYPES_DATATYPESEVENT_OBJECTARGDEMOEVENT,
                      (LSUSHORT)N_DATATYPES_OBJECTARGDEMOEVENT_ARGS, Args,
                      LSIR_EVM_INTERRUPT, LSIR_EVX_COMPLETE));


}
// -----------------------------------------------------------------------------
void Datatypes::LSXRaiseEvent_StringArgsDemoEvent(LSXString theByvalArg, LSXString& theByrefArg)
{
   LSVALUE Args[N_DATATYPES_STRINGARGSDEMOEVENT_ARGS];

   LSXValue EventtheByvalArg((LSVALTYPE)LSVT_STRING, LsiInst);
   EventtheByvalArg.set(theByvalArg);
   Args[0] = *( (PLSVALUE)EventtheByvalArg );

   LSXValue EventtheByrefArg((LSVALTYPE)LSVT_STRING|LSVT_BYREF, LsiInst);
   EventtheByrefArg.set(theByrefArg);
   Args[1] = *( (PLSVALUE)EventtheByrefArg );



   LSICALL(RaiseEvent(this->GetInterfacePtr(), CDATATYPES_DATATYPESEVENT_STRINGARGSDEMOEVENT,
                      (LSUSHORT)N_DATATYPES_STRINGARGSDEMOEVENT_ARGS, Args,
                      LSIR_EVM_INTERRUPT, LSIR_EVX_COMPLETE));

   //Set the byref args here
   LSXArgs ArgList(Args, N_DATATYPES_STRINGARGSDEMOEVENT_ARGS, LsiInst);
   theByrefArg =  ArgList.getArg(2).getString();
}
