/*========================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: lsxapplx.cpp

   Description:
      Datatypes specific functions that are called from the "common"
      code in lsx\src\common

      This file has knowledge of the client's application, and
      should therefore be modified to implement application
      class functionality as required.

      The LSXBASE.CPP code will also be making calls to certain
      LSX... functions that must be implemented in an application
      specific way.  Examples of such functions are those for GUID
      and class id handling, registering and creating application
      classes, and loading class specific text strings.

\*========================================================================*/

#define INITGUID 1      // force GUIDs to be defined in the code

//{{LSX_AUTHOR_CODE_Include_1
//}}

#include "lsxapplx.h"
#include "lsxbase.hpp"
#include "textstr.h"
#include "lsxsess.hpp"
#include "globalconst.h"

#include "Datatypes.hpp"

#include "iDatatypes.tab"   // class registration tables for Datatypes

//{{LSX_AUTHOR_CODE_Include_2
//}}

/* **********************************************************************
*
*  Globals
*/

/***
   Here is the table of full class ids. Offset 0 is empty,
   because the short ids start with 1, and we want to use
   those as a direct index.

   The easiest way to do this is to declare a static struct
   (using the standard macros) for each class/guid, then load
   pointers to those into a table.
***/

// The first one is all 0's and it's used to ref parent classes which don't exist

DEFINE_GUID(c_NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

/**
   the GUID definitions for the Notes LSX back-end classes are in lsxnotes.hpp
**/
#include "lsxnotes.hpp"          // GUIDs for Notes LSX back-end classes

/**
   the other GUIDs come from your guidfile.h

   only #include this file once for each LSX
**/
#include "guidfile.h"            // There is a guidfile.h for each LSX.

static const GUID * guidTable[] =
{
   &c_NULL,

   // list Notes LSXBE GUIDs first

   /**
      GUID table items for the Notes LSX back-end classes are in lsxnotes.inc
   **/

#include "lsxnotes.inc"          // GUIDs for Notes LSX back-end classes

   // list your GUIDs here

   &c_Session,
   &c_Datatypes,
};

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

LSULONG LSXGetGUIDBase()
{
   return (LSULONG) (LSX_YOUR_GUID_BASE_UL);
}

LSUSHORT LSXGetGUIDOffset()
{
   return (LSUSHORT) (LSX_YOUR_GUID_OFFSET_US);
}


/*
*  This routine takes a client class id (#defined in textstr.h),
*  and returns a pointer to a GUID struct, containing the full
*  16-byte id used to register the class with Script (and ole).
*  The pointer returned is static (read-only) storage, and can
*  safely be passed back to Script (or ole) as a class id.
*/

LSPTR(GUID) LSXGetFullClassID(LSUSHORT id)
{
   LSUSHORT inx = LSX_CLASS_ORDINAL(id);  // index into GUID table

   if (id < ::LSXGetFirstClassId() || id > ::LSXGetLastClassId())
      return (LSPTR(GUID))LSNULL;

   else return (LSPTR(GUID))guidTable[inx];
}

LSPTR(GUID) LSXGetClassIDRef(LSADTCLASSID FullId)
{
   LSUSHORT elems = sizeof(guidTable)/sizeof(LSPTR(GUID));

   for (LSUSHORT i = 0; i < elems; i++)
   {
      if ( memcmp(&FullId, guidTable[i], sizeof(GUID)) == 0 )
         return (LSPTR(GUID))guidTable[i];
   }

   assert(LSFALSE);
   return LSNULL;
}
/*
*  This routine gets a pointer to the entire static table. The
*  table is used in some of the registration and array routines.
*/

LSPTR(LSPTR(GUID)) LSXGetClassIDTable()
{
   return (LSPTR(LSPTR(GUID))) guidTable;
}

LSPTR(LSXLsiSession) LSXCreateLSISession(LShINSTANCE hInst)
{
   return(new (hInst) LSXLsiSession(hInst));
}

void LSXDeleteLSISession(LSPTR(LSXLsiSession) pSession)
{
   delete pSession;
}

LSREGNAMETYPE LSXGetStringType()
{
   return CHARSET;
}
/* **********************************************************************
*
*  Class, property, method and const names
*/
static TEXTTABLE gDatatypesNames[] =
{
   {CDATATYPES_DATATYPES_ID,   (LSPLTSTR)"Datatypes"},

   {CDATATYPES_DATATYPESPROP_ABOOLEAN,   (LSPLTSTR)"ABoolean"},
   {CDATATYPES_DATATYPESPROP_ACURRENCY,   (LSPLTSTR)"ACurrency"},
   {CDATATYPES_DATATYPESPROP_ACURRENCYARRAY,   (LSPLTSTR)"ACurrencyArray"},
   {CDATATYPES_DATATYPESPROP_ADATE,   (LSPLTSTR)"ADate"},
   {CDATATYPES_DATATYPESPROP_ADATEARRAY,   (LSPLTSTR)"ADateArray"},
   {CDATATYPES_DATATYPESPROP_ALONG,   (LSPLTSTR)"ALong"},
   {CDATATYPES_DATATYPESPROP_ALONGARRAY,   (LSPLTSTR)"ALongArray"},
   {CDATATYPES_DATATYPESPROP_ANOBJECT,   (LSPLTSTR)"AnObject"},
   {CDATATYPES_DATATYPESPROP_ANOBJECTARRAY,   (LSPLTSTR)"AnObjectArray"},
   {CDATATYPES_DATATYPESPROP_ASHORT,   (LSPLTSTR)"AShort"},
   {CDATATYPES_DATATYPESPROP_ASINGLE,   (LSPLTSTR)"ASingle"},
   {CDATATYPES_DATATYPESPROP_ASTRING,   (LSPLTSTR)"AString"},
   {CDATATYPES_DATATYPESPROP_ASTRINGARRAY,   (LSPLTSTR)"AStringArray"},
   {CDATATYPES_DATATYPESPROP_AVARIANT,   (LSPLTSTR)"AVariant"},

   {CDATATYPES_DATATYPESMETHOD_BOOLEANDEMOFUNCTION,   (LSPLTSTR)"BooleanDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_CURRENCYARRAYDEMOFUNCTION,   (LSPLTSTR)"CurrencyArrayDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_CURRENCYDEMOFUNCTION,   (LSPLTSTR)"CurrencyDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_DATEARRAYDEMOFUNCTION,   (LSPLTSTR)"DateArrayDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_DATEDEMOFUNCTION,   (LSPLTSTR)"DateDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_MULTIDIMARRAYDEMOFUNCTION,   (LSPLTSTR)"MultiDimArrayDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_NEW,   (LSPLTSTR)"New"},
   {CDATATYPES_DATATYPESMETHOD_NUMBERARRAYDEMOFUNCTION,   (LSPLTSTR)"NumberArrayDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_NUMBERDEMOFUNCTION,   (LSPLTSTR)"NumberDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_OBJECTARRAYDEMOFUNCTION,   (LSPLTSTR)"ObjectArrayDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_OBJECTDEMOFUNCTION,   (LSPLTSTR)"ObjectDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_RAISINGEVENTSDEMOMETHOD,   (LSPLTSTR)"RaisingEventsDemoMethod"},
   {CDATATYPES_DATATYPESMETHOD_STRINGARRAYDEMOFUNCTION,   (LSPLTSTR)"StringArrayDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_STRINGDEMOFUNCTION,   (LSPLTSTR)"StringDemoFunction"},
   {CDATATYPES_DATATYPESMETHOD_VARIANTDEMOMETHOD,   (LSPLTSTR)"VariantDemoMethod"},

   {CDATATYPES_DATATYPESEVENT_NUMBERARGSDEMOEVENT,   (LSPLTSTR)"NumberArgsDemoEvent"},
   {CDATATYPES_DATATYPESEVENT_OBJECTARGDEMOEVENT,   (LSPLTSTR)"ObjectArgDemoEvent"},
   {CDATATYPES_DATATYPESEVENT_STRINGARGSDEMOEVENT,   (LSPLTSTR)"StringArgsDemoEvent"},



//{{LSX_AUTHOR_CODE_Constant_Strings
//}}

};

#define NumDatatypesNames ((sizeof(gDatatypesNames)) / (sizeof(TEXTTABLE)))

static CONST_REG_DATA *constArgs;

#define  N_DATATYPES_CONST  0

/*********************************************************************
*
*   Datatypes specific error messages
*/
static TEXTTABLE gDatatypesErrorMessages[] =
{

// Put your error message strings here, following this model
//
//{{LSX_AUTHOR_CODE_Error_Messages
   {ERR_DATATYPES_INIT_DATATYPES_FAILED,   (LSPLTSTR) "LSXDatatypes: Could not initialize Datatypes"},
   {ERR_DATATYPES_INIT_DATATYPES_FAILED,   (LSPLTSTR)"Datatypes: Could not initialize Datatypes"},
   {ERR_DATATYPES_WRONG_ARRAY_DIM, (LSPLTSTR)"Datatypes: Wrong number of array dimensions."},
   {ERR_DATATYPES_ZERO_DIMMED_ARRAY, (LSPLTSTR)"Datatypes: Array has 0 dimensions"}

//}}
};

#define NumDatatypesErrors ((sizeof(gDatatypesErrorMessages)) / (sizeof(TEXTTABLE)))

/* **********************************************************************
*
*  Class version information
*/
static CLASS_VERSION_INFO gClassVersions[] =
{
   {CDATATYPES_DATATYPES_ID,     100},   // version 1.00

};

#define NumClasses ((sizeof(gClassVersions)) / (sizeof(CLASS_VERSION_INFO)))

/*
*  All client's must implement these functions.
*/

/*
*  The base class needs to be able to find out the values of the
*  LSX_FIRST_CLASS and the LSX_LAST_CLASS id's and, for OLE automation,
*  the class id's for the OLE Session class and the LSX_OLEMAIN_CLASS.
*/

LSUSHORT LSXGetFirstClassId()
{
   return (LSX_FIRST_CLASS);
}

LSUSHORT LSXGetLastClassId()
{
   return (LSX_LAST_CLASS);
}

#if defined (OLE_PLATFORM)

LSUSHORT LSXGetOleMainClassId()
{
   return (LSX_OLEMAIN_CLASS);
}

LSUSHORT LSXGetOleClassId()
{
   return (LSX_OLE_CLASS);
}

#endif   // (OLE_PLATFORM)

/*
*  The client needs to describe how to load a text string representing a
*  class name, a property name, or the name of a method.
*  For example, strings may be loaded from a static table (as here) or
*  from an external resource file, as is common in Windows and in PM.
*/

LSSSHORT LSXGetTextString(LSUSHORT id, LSPLTSTR buffer, LSUSHORT max_len)
{
   int         i = 0;
   LPTEXTTABLE pTableItem=LSNULL;
   LSBOOL      found=LSFALSE;

   memset(buffer, 0x00, max_len);
   while ((!found) && (i < NumDatatypesNames))
   {
      pTableItem= &gDatatypesNames[i];

      if (pTableItem->iTextId == id)
      {
         strcpy(buffer, (const char *) pTableItem->cTextStr);
         found=LSTRUE;
      }
      i++;
   }
   assert (found==LSTRUE);
   return strlen(buffer);
}

/*
*  The client needs to describe how to load a text string representing an
*  error message.
*  For example, strings may be loaded from a static table (as here) or
*  from an external resource file, as is common in Windows and in PM.
*/

LSSSHORT LSXGetErrorText(LSUSHORT id, LSPLTSTR buffer, LSUSHORT max_len)
{
   int         i = 0;
   LPTEXTTABLE pTableItem=LSNULL;
   LSBOOL      found=LSFALSE;

   memset(buffer, 0x00, max_len);
   while ((!found) && (i < NumDatatypesErrors))
   {
      pTableItem= &gDatatypesErrorMessages[i];

      if (pTableItem->iTextId == id)
      {
         strcpy(buffer, (const char *) pTableItem->cTextStr);
         found=LSTRUE;
      }
      i++;
   }
   assert (found==LSTRUE);
   return strlen(buffer);
}

/*
*  The class registration code needs to be told the "version" level of the
*  class being registered.  It is important to update the version number
*  whenever there is a change to the class registration information -
*  particularly with regard to the id's of methods, properties, etc.
*  If the id's changed and you do not tell LS this at registration time,
*  the LS run-time is likely to send messages to the LSX which have the
*  obsolete method/property etc. id information.  This will cause the LSX
*  to behave unpredictably.
*/

/*  Revision:
 *
 *  It turns out that the functionality in the above explanation is not
 *  actually implemented in LotusScript yet.  The best practice is to not
 *  modify the ids of your classes, methods, etc. once the script has been
 *  compiled.  This way, old scripts will still work.  If you add new
 *  methods, etc, with new ids, the script code will be new as well, so
 *  the compile will happen automatically.
*/

LSADTVERSION LSXGetClassVersion(LSUSHORT class_id)
{
   LSSSHORT       i=0;
   LPVERSION_INFO pVersionItem=LSNULL;
   LSBOOL         found=LSFALSE;
   LSADTVERSION   version=100;   // default is version 1.00 (arbitrary choice)

   while ((!found) && (i < NumClasses))
   {
      pVersionItem = &gClassVersions[i];

      if (pVersionItem->iClassId == class_id)
      {
         version = pVersionItem->iVersion;
         found=LSTRUE;
      }
      i++;
   }
   assert (found==LSTRUE);
   return version;
}

LS_CPP_PASCAL_LINKAGE_BEGIN

/*********************************************************************
*
*  Register all of this dll's objects with LSI
*
*  Registration tables are in the *.TAB etc. files
*/

//{{LSX_AUTHOR_CODE_Register_Tables_Globals
//}}

LSICLI(LSSTATUS)  RegisterClientClasses(
   LShINSTANCE hInst, LShMODULE hMod, LSPLTSTR pLSXDLLName)
{
   LSSTATUS status = LSX_OK;

   if (status == LSX_OK)
   {
      // register Datatypes Datatypes class

      status = ::LSXRegisterOneClass(hInst, CDATATYPES_DATATYPES_ID, LSNULL,
         Datatypes_propnameids, Datatypes_gprops, N_DATATYPES_PROPS,
         Datatypes_methodnameids, Datatypes_gmethods, N_DATATYPES_METHODS,
         Datatypes_eventnameids, Datatypes_gevents, N_DATATYPES_EVENTS,
         CHARSET,     // Class name string type
         CHARSET,     // string type for Class Control Procedure
         pLSXDLLName, (LSPLTSTR)LSX_CLASS_CONTROL_NAME, hMod,
         LSI_ADT_REFERENCED );
   }

   if (status == LSX_OK)
   {
      LSPLTCHAR   buffer[LSX_MAX_BUFF_LEN];
      LSSSHORT i, len;

      for (i = 0; i < N_DATATYPES_CONST; i++)
      {
         len = ::LSXGetTextString(constArgs[i].resid, buffer, (LSX_MAX_BUFF_LEN-1));
         status = hInst->ConstRegister(
                           LSI_REGNAME_PLATFORM, // string type
                           (LSPLTSTR)buffer,
                           LSI_DT_SHORT,
                           LSVAR_SCOPE_PUBLIC,
                           &constArgs[i].value,
                           LSNULL,
                           hMod);             // module to register into
      }
   }

  //{{LSX_AUTHOR_CODE_Register_Globals
  //}}

   return status;
}

LS_CPP_PASCAL_LINKAGE_END

LSSTATUS CreateClientObjects( LShINSTANCE     hInst,
                              PLSADTINSTDESC  pInstDesc,
                              LSADTMSGPARAM   param)
{
   LSPTR(LSXLsiSession)   pAppSession=LSNULL;
   LSPTR(Datatypes)      pDatatypes=LSNULL;
   LSSTATUS               retval = LSX_OK;

   /*
      There's no object yet, of course.
      Here's an interesting situation: we have all these objects
      which need to be created in the context of some container
      but we want to support users just doing New "object" in
      LotusScript. So, we make them pass the containing object
      as an argument (we don't make them pass a containing Session
      for creating a client object; since there is only one session,
      we just find it).

      Note that until we 'New' the object in C++ there's no way to
      invoke a constructor. We could pass the container into the
      constructor, and have the constructor call the container to
      insert the new thing into the container's list. Or, we could
      unpack the arg list, parse out the container object, and
      invoke a create method on the container for the new object.
      The first is more code in the objects, the second is more
      code right here.

      For now, we go with the first choice (pass the container
      object to the constructor of the new object, which needs
      to have a back-pointer anyway)
   */

   pAppSession =
      (LSPTR(LSXLsiSession))::LSXFindSession(hInst, LSX_OBJTYPE_LSISESS);

   if (pAppSession == LSNULL)
   {
      pAppSession = new (hInst) LSXLsiSession(hInst);
      /*
         If the creation of the Session object failed, return an error to LS
      */
      retval= (pAppSession)   ? pAppSession->LSXGetErrorCode()
                                 : LSI_ERR_ABORT;
   }
   assert (pAppSession);

   //Initialize the args object
   LSXArgs ArgList(param.mpCreate, hInst);

   if (retval == LSX_OK)
   {
      switch (LSX_GETCLASSID(pInstDesc->idClass))
      {
      case CDATATYPES_DATATYPES_ID:
      {
         // force a new scope so we can use the same variable names
         // in different cases.
         
      //Extract the arguments
      LSSSHORT theIntArg =  ArgList.getArg(1).getShort();
      LSSLONG theLongArg =  ArgList.getArg(2).getLong();
      LSFLOAT4 theSingleArg =  ArgList.getArg(3).getSingle();
      LSXString theStringArg =  ArgList.getArg(4).getString();

         pDatatypes = new (hInst) Datatypes(pAppSession, theIntArg, theLongArg, theSingleArg, theStringArg);
         pInstDesc->hdlClient =(pDatatypes) ? pDatatypes->GetInterfacePtr() : LSNULL;
         

         // If the creation of the Datatypes object failed, return an error to LS.
         retval = (pDatatypes) ? pDatatypes->LSXGetErrorCode() : LSI_ERR_ABORT;
      }  
      break;


      default:
         assert (LSFALSE);
         retval = LSI_ERR_INVALADT;
         break;
      }
   }
   return retval;
}

#if defined(OLE_PLATFORM) && defined(WIN32)
      /* Table of OLE/COM registration information for DLLRegister() and DLLUnregister().
         The first entry is the {Project Name, NoteSession LSXID, TypeLibrary CLSID} */
      const OLE_CLASS_REGISTRY_INFO gOLERegInfo[] = 
      {
          		{"Datatypes", CDATATYPES_DATATYPES_ID, c_Datatypes},

      };
      const int gOLERegInfoEntries = sizeof(gOLERegInfo) / sizeof(OLE_CLASS_REGISTRY_INFO);
#endif // OLE_PLATFORM && WIN32

//{{LSX_AUTHOR_CODE_OtherCode
//}}

