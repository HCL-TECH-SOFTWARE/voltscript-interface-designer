/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: Datatypes.cpp

   Description:
      Implementation of methods for the scriptable "Datatypes" object

\*============================================================================*/

//{{LSX_AUTHOR_CODE_Include_1
//}}

#include "Datatypes.hpp"

// includes for the objects defined in your LSX


//{{LSX_AUTHOR_CODE_Include_2
//}}

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 * Constructors/Destructors
 *
 ******************************************************************************/
// This constructor is called when the script 'new's one or calls
// CreateDatatypes on the container class.

Datatypes:: Datatypes( LSPTR(LSXLsiSession) pContainer, LSSSHORT theIntArg, LSSLONG theLongArg, LSFLOAT4 theSingleArg, LSXString theStringArg)
   : LSXBase((LSPLTSTR)"Datatypes", pContainer->LSXGetInstance(), CDATATYPES_DATATYPES_ID, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init1
   //}}
   m_ABoolean(LSXFalse),
   m_ACurrency( ),
   m_ACurrencyArray(1),
   m_ADate(LsiInst),
   m_ADateArray(),
   m_ALong(theLongArg),
   m_ALongArray(1),
   m_AnObject(LSNULL),
   m_AnObjectArray(),
   m_AShort(theIntArg),
   m_ASingle(theSingleArg),
   m_AString(theStringArg),
   m_AStringArray(1),
   m_AVariant(LSNULL)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init1
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor1
	m_ACurrency.Hi = 0;
	m_ACurrency.Lo = 0;
	
   //}}

   // You must do reference counting whenever you maintain a
   // reference to an object that LS knows about.  Otherwise
   // it will get deleted when LS is done with it, even if you aren't.
   if (m_AnObject)
      m_AnObject->AddRef();

}

// ------------------------------------------------------------------------------

// This version of the constructor is called by a derived class for its 
// constructor initialization.

Datatypes:: Datatypes(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer, LSSSHORT theIntArg, LSSLONG theLongArg, LSFLOAT4 theSingleArg, LSXString theStringArg )
   : LSXBase((LSPLTSTR)"Datatypes", pContainer->LSXGetInstance(), classId, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init2
   //}}
   m_ABoolean(LSXFalse),
   m_ACurrency( ),
   m_ACurrencyArray(1),
   m_ADate(LsiInst),
   m_ADateArray(),
   m_ALong(theLongArg),
   m_ALongArray(1),
   m_AnObject(LSNULL),
   m_AnObjectArray(),
   m_AShort(theIntArg),
   m_ASingle(theSingleArg),
   m_AString(theStringArg),
   m_AStringArray(1),
   m_AVariant(LSNULL)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init2
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor2
	m_ACurrency.Hi = 0;
	m_ACurrency.Lo = 0;
   //}}

   // You must do reference counting whenever you maintain a
   // reference to an object that LS knows about.  Otherwise
   // it will get deleted when LS is done with it, even if you aren't.
   if (m_AnObject)
      m_AnObject->AddRef();

}

//------------------------------------------------------------------------------
//{{LSX_AUTHOR_CODE_Additional_Constructors
//}}
//------------------------------------------------------------------------------

Datatypes:: ~Datatypes()
{
   //{{LSX_AUTHOR_CODE_Destructor
   //}}

   

   // Let LS know we are done with these.
   if (m_AnObject)
      m_AnObject->DropRef();

}

/*******************************************************************************
 *
 * Method Definitions for methods that are exposed to LotusScript
 *
 *******************************************************************************/
LSXBool Datatypes::BooleanDemoFunction(LSXBool ByValArg, LSXBool& ByRefArg)
{
   //{{LSX_AUTHOR_CODE_Method_BooleanDemoFunction

   LSXBool OrigByRefArg = ByRefArg;

   //Toggle the byref Arg (can't do a C++ ! because a C++ True is 1 and
   //a LotusScript True is -1.
   if (ByRefArg == LSXTrue)
      ByRefArg = LSXFalse;
   else
      ByRefArg = LSXTrue;

   //Set the return value to be whether or not the two arguments are the
   //same.
   if (OrigByRefArg == ByValArg)
      return LSXTrue;
   else
      return LSXFalse;

   //}}
}
// -----------------------------------------------------------------------------
LSXCurrencyArray Datatypes::CurrencyArrayDemoFunction(LSXCurrencyArray& InputArray)
{
   //{{LSX_AUTHOR_CODE_Method_CurrencyArrayDemoFunction

   //This method demonstrates the handling of 1-dimensional currency arrays.
	//The method receives a 1-dimensional array as an argument, reverses the
	//order of the array and uses the result as the return value, and
	//modifies the elements in the argument array, to be reflected back in 
	//the script.
	
	//Check that the array is 1-dimensional as this method is expecting
	if (InputArray.getDimCount() != 1)
	{
		this->LSXRaiseError(ERR_DATATYPES_WRONG_ARRAY_DIM);
	}

   // Create a new array that is a copy of the argument array, with it's
	// order reversed	
	
	//Note that array return values are always base 0 since there
	// is no way to know what Option Base is set to in the script.
	LSUSHORT len = InputArray.getLength();
	LSXCurrencyArray RetArray(len);
	for (LSUSHORT i = 0; i < len; i++)
		RetArray[i] = InputArray[len - i - 1];

	//Increase the size of the input array (only if not a fixed array)
	//and initialize the new elements. Preserve the existing elements
	//in the array.
	if (! InputArray.isFixedSize())
	{
		InputArray.Resize(len + 1, LSTRUE);
		InputArray[len].Lo = 44444;
		len = len + 1;
	}

   //Modify the elements in the argument array.  The inputted array
	//will show the changed values in the script.
	for (LSUSHORT j = 0; j < len; j++)
		InputArray[j].Lo = InputArray[j].Lo + 1;

   return RetArray;

   //}}
}
// -----------------------------------------------------------------------------
LSsCurrency Datatypes::CurrencyDemoFunction(LSsCurrency theByvalArg, LSsCurrency& theByrefArg)
{
   //{{LSX_AUTHOR_CODE_Method_CurrencyDemoFunction

 	//This method demonstrates passing currency arguments
	//by value and by reference and returning a currency value.
	//This first argument is by value, the second argument
	//is by reference.

	//Modify the byref argument
	theByrefArg.Lo = theByrefArg.Lo + 1;

	LSsCurrency RetVal = theByvalArg;
	RetVal.Lo = RetVal.Lo + 1000;

	return RetVal;

   //}}
}
// -----------------------------------------------------------------------------
LSXDateArray Datatypes::DateArrayDemoFunction(LSXDateArray& InputArray)
{
   //{{LSX_AUTHOR_CODE_Method_DateArrayDemoFunction

   //This method demonstrates the handling of 1-dimensional date arrays.
	//The method receives a 1-dimensional array as an argument, reverses the
	//order of the array and uses the result as the return value, and
	//modifies the elements in the argument array, to be reflected back in 
	//the script.
	
	//Check that the array is 1-dimensional as this method is expecting
	if (InputArray.getDimCount() != 1)
	{
		this->LSXRaiseError(ERR_DATATYPES_WRONG_ARRAY_DIM);
	}

   // Create a new array that is a copy of the argument array, with it's
	// order reversed

	//Note that array return values are always base 0 since there
	// is no way to know what Option Base is set to in the script.
	LSUSHORT len = InputArray.getLength();
	LSXDateArray RetArray(len, LSXGetInstance());
	for (LSUSHORT i = 0; i < len; i++)
		RetArray[i] = InputArray[len - i - 1];

   //Increase the size of the input array (only if not a fixed array)
	//and initialize the new elements. Preserve the existing elements
	//in the array.
	if (! InputArray.isFixedSize())
	{
		InputArray.Resize(len + 1, LSTRUE);

		InputArray[len].setMonth(7);
		InputArray[len].setDay(4);
		InputArray[len].setYear(1976);
	}

   //Modify the elements in the argument array by adding 5 years and 10 minutes to each.
	//The inputted array will show the changed values in the script.

	for (LSUSHORT j = 0; j < InputArray.getLength(); j++)
	{
		LSXDate& d = InputArray[j];
		if ( ! d.isNullDate())
			d.setYear(d.getYear() +  5);

		if ( ! d.isNullTime())
			d.setMinute(d.getMinute() +  10);
	}

   return RetArray;

   //}}
}
// -----------------------------------------------------------------------------
LSXDate Datatypes::DateDemoFunction(LSXDate the1stDate, LSXDate& the2ndDate)
{
   //{{LSX_AUTHOR_CODE_Method_DateDemoFunction

 	//This method demonstrates passing date arguments
	//by value and by reference and returning a date value.
	//This first argument is by value, the second argument
	//is by reference.

	//Modify the byref argument by adding 5 years to the date and
	//10 minutes to the time.
	the2ndDate.setYear(the2ndDate.getYear() +  5);
	the2ndDate.setMinute(the2ndDate.getMinute() +  10);

	//Set the return value to be the first argument - 5 years
	LSXDate RetVal(the1stDate);
	RetVal.setYear(the1stDate.getYear() - 5);

   return RetVal;

   //}}
}
// -----------------------------------------------------------------------------
LSXShortArray Datatypes::MultiDimArrayDemoFunction(LSXShortArray& InputArray)
{
   //{{LSX_AUTHOR_CODE_Method_MultiDimArrayDemoFunction

   //This method demonstrates the handling of 2-dimensional numeric arrays.
	//The method receives a 2-dimensional array as an argument, switches the
	//rows and columns of the array and uses the result as the return value, and
	//resizes the elements in the argument array and modifies them, to be reflected 
	//back in the script.
		
	//Check that the array is 2-dimensional as this method is expecting
	if (InputArray.getDimCount() != 2)
	{
		this->LSXRaiseError(ERR_DATATYPES_WRONG_ARRAY_DIM);
	}

   // Create a new array for the return value that is a copy of the argument array, 
	//with it's rows and columns switched.

	const int COLS = 0;
	const int ROWS = 1;

	LSUSHORT Elems[2];
	Elems[ROWS] = InputArray.getLength(ROWS);
	Elems[COLS] = InputArray.getLength(COLS);

	//Note that array return values are always base 0 since there
	// is no way to know what Option Base is set to in the script.
	LSXShortArray RetArray(InputArray.getDimCount(), Elems);

	LSUSHORT iCol;
	LSUSHORT iRow;
	for (iRow=0; iRow < Elems[ROWS]; iRow++)
	{
		for (iCol=0; iCol < Elems[COLS]; iCol++)
		{
			RetArray[RetArray.getIndex(iCol, iRow)] = InputArray[InputArray.getIndex(iRow, iCol)];
		}
	}

	//Increase the size of the last dimension in the array.  Note that 
	//fixed-size arrays can not be resized.  An array that comes in from
	//LotusScript as an argument may be fixed size based on the way the
	//script writer declared it.  Also note that if the Preserve option
	//is used, only the last dimension of the array may be resized.
	if (! InputArray.isFixedSize())
	{
		LSUSHORT newSize[2];
		newSize[COLS] = InputArray.getLength(COLS);
		newSize[ROWS] = InputArray.getLength(ROWS) + 1;
		InputArray.Resize(newSize, LSTRUE);
		for (LSSSHORT iCol=0; iCol < newSize[COLS]; iCol++)
		{
			//Multi-dimensional arrays are actually stored as single dimensional arrays.
			//Use getIndex to translate between logical indices and the actual index.
			InputArray[InputArray.getIndex(iCol, newSize[ROWS]-1)] = iCol*10 + newSize[ROWS] - 1;
		}
	}

   //Modify the elements in the argument array.  The inputted array
	//will show the changed values in the script. Since we don't care
	//about the individual elements in this case, we can treat the array
	//as if it were single dimensional since it is stored that way.
		for (LSUSHORT i = 0; i < InputArray.getElemCount(); i++)
			InputArray[i] = InputArray[i] + 100;

	return RetArray;

   //}}
}
// -----------------------------------------------------------------------------
LSXLongArray Datatypes::NumberArrayDemoFunction(LSXLongArray& InputArray)
{
   //{{LSX_AUTHOR_CODE_Method_NumberArrayDemoFunction

   //This method demonstrates the handling of 1-dimensional numeric arrays.
	//The method receives a 1-dimensional array as an argument, reverses the
	//order of the array and uses the result as the return value, and
	//modifies the elements in the argument array, as well as the size of the
	//array, to be reflected back in the script.
		
	//Check that the array is 1-dimensional as this method is expecting
	if (InputArray.getDimCount() != 1)
	{
		this->LSXRaiseError(ERR_DATATYPES_WRONG_ARRAY_DIM);
	}

   // Create a new array that is a copy of the argument array with it's
	// order reversed. Note that array return values are always base 0 since there
	// is no way to know what Option Base is set to in the script.
	LSUSHORT len = InputArray.getLength();
	LSXLongArray RetArray(len);
	for (LSUSHORT i = 0; i < len; i++)
		RetArray[i] = InputArray[len - i - 1];

   //Increase the size of the input array and then modify it's elements.
	//The changed values will be reflected in the script.  You can only
	//do this if the script writer passed in a dynamic array, not a fixed
	//array.
	if (! InputArray.isFixedSize())
	{
		len = InputArray.getLength() + 1;
		InputArray.Resize(len, LSTRUE);
		InputArray[len - 1] = 4;
	}
	for (LSUSHORT j = 0; j < len; j++)
		InputArray[j] = InputArray[j] + 100;

   return RetArray;

   //}}
}
// -----------------------------------------------------------------------------
LSSLONG Datatypes::NumberDemoFunction(LSSSHORT Arg1, LSSLONG& Arg2)
{
   //{{LSX_AUTHOR_CODE_Method_NumberDemoFunction

	//This method demonstrates passing numeric arguments
	//by value and by reference and return a number value.
	//This first argument is by value, the second argument
	//is by reference.

	LSULONG OrigArg2 = Arg2;

	Arg2 = Arg2 * 2;

   return Arg1 + OrigArg2;

   //}}
}
// -----------------------------------------------------------------------------
DatatypesArray Datatypes::ObjectArrayDemoFunction(DatatypesArray& InputArray)
{
   //{{LSX_AUTHOR_CODE_Method_ObjectArrayDemoFunction

	//Note that array return values are always base 0 since there
	// is no way to know what Option Base is set to in the script.
	DatatypesArray RetArray(InputArray.getLength(), LSXGetInstance());

   //No [] syntax because we need to refcount these and need to be able to 
	//distinguish between getting and setting.  If you do a "get" here, be sure
	//to refcount any objects that you are going to hang on to outside the scope
	//of this function. "set" handles the refcounting for you.

	//Return value is a copy of the input array in reverse order
   LSUSHORT len = InputArray.getLength();
	for (LSUSHORT i = 0; i < len; i++)
	{
	   RetArray.setElemAt(i, InputArray.getElemAt(len - i - 1));
   }
	//Because it is passed by reference, you can modify the input array and
	//have the changes be reflected back in the script.
	//We will substitute the second element with "this" Simple.
	InputArray.setElemAt(1, *this);

   //Also, we can resize the input array as long as it was declared in
   //the script as dynamic.
	if (! InputArray.isFixedSize())
	{
		InputArray.Resize(len + 1, LSTRUE);
      InputArray.setElemAt(len, *m_AnObject);
   }

   return RetArray;

   //}}
}
// -----------------------------------------------------------------------------
Datatypes& Datatypes::ObjectDemoFunction(const Datatypes& theConstRefObj, Datatypes& theRefObj)
{
   //{{LSX_AUTHOR_CODE_Method_ObjectDemoFunction

 	//This method demonstrates passing object arguments
	//and returning an object value.  Objects are always
	//passed by reference, allowing the properties of the
	//object to be changed inside this method and reflected
	//in the script.  However, if you selected to pass "byval"
	//in the declaration in the wizard, the reference is generated
	//as const.

	//Change a property value of one of the non-const ("byref") arguments
   theRefObj.m_ALong = theConstRefObj.m_ALong;

	Datatypes& RetVal = theRefObj;

	//Set the m_AnObject data member to the2ndObj.  
	
	//Remember that you must reference count all instances of all objects that 
	//LotusScript doesn't know that you are holding.  Otherwise, when LS, is done
	//with the object and does a DropRef, the refcount will go to 0, and the object
	//will be destroyed, even though you are still using it in your LSX.
	//If your reference to the object is just in local scope (i.e. RetVal), you
	//don't need to worry about this.

	m_AnObject->DropRef(); //Drop the reference on the original object
	m_AnObject = &theRefObj;
	m_AnObject->AddRef();  //Add the reference to the new object.


   //Use the original 2nd argument as a return value
   return RetVal;
   //}}
}
// -----------------------------------------------------------------------------
void Datatypes::RaisingEventsDemoMethod()
{
   //{{LSX_AUTHOR_CODE_Method_RaisingEventsDemoMethod

	//This routine demonstrates how to raise events in LotusScript.

	//Raise the NumberArgs event, an event that passing two arguments,
	//the first by value, the second by reference.
	LSSLONG ByRefLongArg = 10;
	
	LSXRaiseEvent_NumberArgsDemoEvent(7, ByRefLongArg);
	//If the script changed the byref arg, the variable ByRefArg will now
	//have the new value.

	//Raise the StringArgs event, an event that passing two arguments,
	//the first by value, the second by reference.
	LSXString ByRefStringArg = LIT_STR("A ByRef String");
	
	LSXRaiseEvent_StringArgsDemoEvent(LIT_STR("A constant string"), ByRefStringArg);
	//If the script changed the byref arg, the variable ByRefArg will now
	//have the new value.

	//Raise the ObjectArgs event	
	LSXRaiseEvent_ObjectArgDemoEvent(*m_AnObject);
	//If the script changed the byref arg, the variable ByRefArg will now
	//have the new value.


   //}}
}
// -----------------------------------------------------------------------------
LSXStringArray Datatypes::StringArrayDemoFunction(LSXStringArray& InputArray)
{
   //{{LSX_AUTHOR_CODE_Method_StringArrayDemoFunction

   //This method demonstrates the handling of 1-dimensional string arrays.
	//The method receives a 1-dimensional array as an argument, reverses the
	//order of the array and uses the result as the return value, and
	//resizes and modifies the elements in the argument array, to be 
	//reflected back in the script.
	
	//Check that the array is 1-dimensional as this method is expecting
	if (InputArray.getDimCount() != 1)
	{
		this->LSXRaiseError(ERR_DATATYPES_WRONG_ARRAY_DIM);
	}

   // Create a new array that is a copy of the argument array, with it's
	// order reversed

	//Note that array return values are always base 0 since there
	// is no way to know what Option Base is set to in the script.
	LSUSHORT len = InputArray.getLength();
	LSXStringArray RetArray(len);
	for (LSUSHORT i = 0; i < len; i++)
		RetArray[i] = InputArray[len - i - 1];

	//Increase the size of the input array (only if not a fixed array)
	//and initialize the new elements. Preserve the existing elements
	//in the array.
	if (! InputArray.isFixedSize())
	{
		InputArray.Resize(len + 1, LSTRUE);
		InputArray[len] = LIT_STR("*four*");
	}

   //Modify the elements in the argument array.  The inputted array
	//will show the changed values in the script.
	InputArray[0] = LIT_STR("*zero*");
	InputArray[1] = LIT_STR("*one*");
	InputArray[2] = LIT_STR("*two*");
	InputArray[3] = LIT_STR("*three*three*"); //this one will be truncated if the input arg is made

   return RetArray;

   //}}
}
// -----------------------------------------------------------------------------
LSXString Datatypes::StringDemoFunction(LSXString Arg1, LSXString& Arg2)
{
   //{{LSX_AUTHOR_CODE_Method_StringDemoFunction

 	//This method demonstrates passing string arguments
	//by value and by reference and returning a string value.
	//This first argument is by value, the second argument
	//is by reference.

	//Append exclamation points to the 2nd argument
	Arg2 = Arg2 + LIT_STR("!!!");

   return Arg1 + Arg2;

   //}}
}
// -----------------------------------------------------------------------------
void Datatypes::VariantDemoMethod(PLSVALUE Arg1)
{
   //{{LSX_AUTHOR_CODE_Method_VariantDemoMethod


   LSXValue Val(Arg1, LsiInst);

   switch ( LSVT_BASEVALTYPE(Arg1->Type) ) //this masks out LSVT_BYREF, etc.
   {
      case LSVT_STRING:
      {
         LSSTRING str = Val.getUniString();
      }
      
      break;

      case LSVT_SHORT:
      {
         LSSSHORT num = Val.getShort();
      }
      
      break;

    }

   return;

   //}}
}
/*******************************************************************************
 *
 * Internal Method Definitions
 *
 *******************************************************************************/
//{{LSX_AUTHOR_CODE_Internal_Methods
//}}

