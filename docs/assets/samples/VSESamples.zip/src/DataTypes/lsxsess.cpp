/*========================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: LSXSESS.CPP

   Description:
      Implementation of scriptable Session object

      A single instance of this class is instantiated upon execution of the USELSX
      statement.  It is destroyed when the LSX is unloaded.

\*========================================================================*/

//{{LSX_AUTHOR_CODE_Includes
//}}

#include "lsxsess.hpp"
#include "lsxapplx.h"
#include "textstr.h"

#include "Datatypes.hpp"

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/***********************************************************************
*
* LSXLsiSession class methods
*
*/

LSXLsiSession:: LSXLsiSession(LShINSTANCE hInst)
   :  LSXBase((LSPLTSTR)"Datatypes", hInst, CDATATYPES_SESSION_ID),
ContainedObjectList(LSNULL)
//{{LSX_AUTHOR_CODE_Internal_Member_Init1
//}}
{
   //{{LSX_AUTHOR_CODE_Constructor

   //}}

   // Set the object type as LSI Session
   LSXSetObjectType(LSX_OBJTYPE_LSISESS);

   // Add the LSXLsiSession object to the global list
   ::LSXAddSession((LSPTR(LSXBase))this);
}

//***********************************************************************

LSXLsiSession:: ~LSXLsiSession()
{
   //{{LSX_AUTHOR_CODE_Destructor

   //}}

   LSXDeleteList(ContainedObjectList);

   // remove from global list
   ::LSXRemoveSession((LSPTR(LSXBase))this);
}

//***********************************************************************

//{{LSX_AUTHOR_CODE_OtherCode
//}}

