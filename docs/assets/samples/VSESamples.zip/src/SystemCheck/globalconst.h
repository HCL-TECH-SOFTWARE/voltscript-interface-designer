/* ======================================================================== *\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: globalconst.h

   Description:
      The contents of this file will be very different for each different
      client application (LSX).  It contains client application specific
      definitions.
      However, the structure of the file will essentially be the same.
      The file contains the enumberation of all the defined constants.

\*========================================================================*/

#if !defined (GLOBALCONST_H)
#define GLOBALCONST_H

#include "textstr.h"

/*********************************************************************/

/*
   These constants segment the address space for string ids.  If two LSXs
   are being used in the same script and the ids for the elements overlap,
   you will get a USELSX error when the LotusScript host attempts to load
   the 2nd LSX.  Use the Project document in the Wizard to change this
   number.  Also, keep in mind that whenever this number is changed, all
   scripts that use the LSX must be recompiled.
*/

enum class SystemCheckGlobalConstants : LSUSHORT {
 
};

#endif   // #if !defined (GLOBALCONST_H)
