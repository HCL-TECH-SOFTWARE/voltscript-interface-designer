/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: SystemInfo.cpp

   Description:
      Implementation of methods for the scriptable "SystemInfo" object

\*============================================================================*/

//{{LSX_AUTHOR_CODE_Include_1
#if defined(WIN32) || defined(WIN16)
#include <windows.h>
#else
#error  Unsupported Platform...
#endif
//}}

#include "SystemInfo.hpp"

// includes for the objects defined in your LSX


//{{LSX_AUTHOR_CODE_Include_2
//}}

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 * Constructors/Destructors
 *
 ******************************************************************************/
// This constructor is called when the script 'new's one or calls
// CreateSystemInfo on the container class.

SystemInfo:: SystemInfo( LSPTR(LSXLsiSession) pContainer)
   : LSXBase((LSPLTSTR)"SystemInfo", pContainer->LSXGetInstance(), CSYSTEMCHECK_SYSTEMINFO_ID, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init1
   //}}
   m_FreeDiskSpace(0L),
   m_OSBuildNumber(0),
   m_OSMinorVersion(0),
   m_OSPlatform(LIT_STR("")),
   m_OSVersion(0),
   m_ProcessorType(LIT_STR("")),
   m_TotalDiskSpace(0L),
   m_TotalPhysicalMemory(0L)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init1
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor1
   //}}

}

// ------------------------------------------------------------------------------

// This version of the constructor is called by a derived class for its 
// constructor initialization.

SystemInfo:: SystemInfo(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer )
   : LSXBase((LSPLTSTR)"SystemInfo", pContainer->LSXGetInstance(), classId, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init2
   //}}
   m_FreeDiskSpace(0L),
   m_OSBuildNumber(0),
   m_OSMinorVersion(0),
   m_OSPlatform(LIT_STR("")),
   m_OSVersion(0),
   m_ProcessorType(LIT_STR("")),
   m_TotalDiskSpace(0L),
   m_TotalPhysicalMemory(0L)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init2
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor2
   //}}

}

//------------------------------------------------------------------------------
//{{LSX_AUTHOR_CODE_Additional_Constructors
//}}
//------------------------------------------------------------------------------

SystemInfo:: ~SystemInfo()
{
   //{{LSX_AUTHOR_CODE_Destructor
/*
void CheckMemory ()
{
	MEMORYSTATUS ms;
	ms.dwLength =  sizeof(ms);
	GlobalMemoryStatus(&ms);

	printf("Percent of memory in use:   %d\n",  ms.dwMemoryLoad); 
	printf("Physical Memory:            %ld\n", ms.dwTotalPhys);
	printf("Available Physical Memory:  %ld\n", ms.dwAvailPhys);
	printf("Paging File:                %ld\n", ms.dwTotalPageFile);
	printf("Available Paging File:      %ld\n", ms.dwAvailPageFile);
	printf("Virtual Memory:             %ld\n", ms.dwTotalVirtual);
	printf("Available Virtual Memory:   %ld\n", ms.dwAvailVirtual); 
}
*/

   //}}

   

}

/*******************************************************************************
 *
 * Method Definitions for methods that are exposed to LotusScript
 *
 *******************************************************************************/
void SystemInfo::DiskCheck(LSXString Drive)
{
   //{{LSX_AUTHOR_CODE_Method_DiskCheck

	LSPLTSTR	driveletter = LSNULL;

	LSBOOL	ret_stat;
	DWORD	dwSectorsPerCluster = 0L;		// address of sectors per cluster 
	DWORD	dwBytesPerSector = 0L;			// address of bytes per sector 
	DWORD	dwNumberOfFreeClusters = 0L;	// address of number of free clusters  
	DWORD	dwTotalNumberOfClusters= 0L;	// address of total number of clusters

	driveletter = Drive;

	ret_stat = GetDiskFreeSpace(driveletter, &dwSectorsPerCluster, &dwBytesPerSector, 
							&dwNumberOfFreeClusters, &dwTotalNumberOfClusters);

	if (ret_stat == TRUE)
	{
		m_FreeDiskSpace = (LSULONG)(dwSectorsPerCluster * dwBytesPerSector * dwNumberOfFreeClusters);
		m_TotalDiskSpace= (LSULONG)(dwSectorsPerCluster * dwBytesPerSector * dwTotalNumberOfClusters);
	}

	return;

   //}}
}
// -----------------------------------------------------------------------------
void SystemInfo::SystemCheck()
{
   //{{LSX_AUTHOR_CODE_Method_SystemCheck

	//	for GetVersionEX
	LSBOOL				ret_status;
	OSVERSIONINFO		osinfo;
	LPOSVERSIONINFO	lpOSInfo = &osinfo;

	//	for GetSystemInfo
	SYSTEM_INFO			internsysinfo;  
	LPSYSTEM_INFO		lpSystemInfo = &internsysinfo;

	//	for GobalMemoryStatus
	MEMORYSTATUS		MemBuff;
	LPMEMORYSTATUS		lpMemBuff = &MemBuff;


	//	required to set the initial size of struct
	lpOSInfo->dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	ret_status = GetVersionEx(lpOSInfo);

	if (ret_status == TRUE)
	{
		m_OSVersion = (LSSSHORT) lpOSInfo->dwMajorVersion;
		m_OSMinorVersion= (LSSSHORT) lpOSInfo->dwMinorVersion;
		m_OSBuildNumber = (LSSSHORT) lpOSInfo->dwBuildNumber;

		switch (lpOSInfo->dwPlatformId)
		{
		case VER_PLATFORM_WIN32s:		
			m_OSPlatform = "Windows 32s";		
			break;

		case VER_PLATFORM_WIN32_WINDOWS:			
			m_OSPlatform = "Windows 95";			
			break;

		case VER_PLATFORM_WIN32_NT:		
			m_OSPlatform = "Windows NT";		
			break;

		default:			
			m_OSPlatform = "UnKnown";			
			break;
		}
	}
	else
	{
		// raise error here
		assert (LSFALSE);
	}

	//Get and process the system info

	GetSystemInfo(lpSystemInfo);

	switch (lpSystemInfo->dwProcessorType)
	{
	case PROCESSOR_INTEL_386:		
		m_ProcessorType = "Intel 386";		
		break;

	case PROCESSOR_INTEL_486:	
		m_ProcessorType = "Intel 486";	
		break;

	case PROCESSOR_INTEL_PENTIUM:		
		m_ProcessorType = "Intel Pentium";		
		break;

	case PROCESSOR_ALPHA_21064:		
		m_ProcessorType = "DEC Alpha 21046";		
		break;

	case PROCESSOR_MIPS_R4000:		
		m_ProcessorType = "MIPS R4000";		
		break;

	default:		
		m_ProcessorType = "Unknown";	
		break;
	}

	lpMemBuff->dwLength = sizeof(MEMORYSTATUS);
	GlobalMemoryStatus(lpMemBuff);
	if ((lpMemBuff->dwTotalPhys)!= NULL)
	{
		m_TotalPhysicalMemory = (LSSLONG) lpMemBuff->dwTotalPhys;
	}
	else
	{
		assert (LSFALSE);
	}
	return;

   //}}
}
/*******************************************************************************
 *
 * Internal Method Definitions
 *
 *******************************************************************************/
//{{LSX_AUTHOR_CODE_Internal_Methods
//}}

