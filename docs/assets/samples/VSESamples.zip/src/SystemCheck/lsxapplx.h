/*========================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: lsxapplx.h

   Description:
      Definitions for application specific items

\*========================================================================*/

#if !defined(LSXAPPLX_H)
#define LSXAPPLX_H

//{{LSX_AUTHOR_CODE_Include1
//}}

// Changing the character set in the Wizard will comment/uncomment these 
// lines to toggle between LMBCS, UNICODE, PLATFORM/ASCII strings.  
// However, UNICODE is not supported on OS390 - so force the use of ASCII

//#define LMBCS_STRINGS
#if !defined(OS390)   /* only if NOT OS390 */
//#define UNICODE_STRINGS
#endif

#include "lsxstrtm.hpp"
#include "lsxarray.hpp"
#include "lsxvalue.hpp"
#include "lsxforeign.hpp"
#include "textstr.h"

//{{LSX_AUTHOR_CODE_Include2
//}}

// Although these would ideally be defined in LSXCOMM, 
// they need to be here in case a single Common is 
// shared with multiple LSXs with different string types.

#if defined(UNICODE_STRINGS)

   typedef LSXUniString             LSXString;
   typedef LSXUniStringArray        LSXStringArray;
   #define CHARSET                  LSI_REGNAME_UNICODE
   #define CHARTYPE                 LSUNICHAR
   #define getString()              getUniString()
   #define getStringArray           getUniStringArray

   // On platforms where a wide character is 2 bytes, you can specify a 
   // literal string by prefixing an 'L'.  On other platforms, you need to 
   // do an actual conversion from a wide character down to a UNICODE 
   // character.

   #if defined(UNIX) || defined(OS2)
      #define LIT_STR(x)            LSXUniString(L##x)
   #else
      #define LIT_STR(x)            L##x  // On Unix, a long is 4 bytes 
   #endif                                 //   not 2, so this doesn't work

#elif defined(LMBCS_STRINGS)

   // Handle LMBCS case for string format -- internal handling is similar to ASCII.
   typedef LSXPltString             LSXString;
   typedef LSXPltStringArray        LSXStringArray;
   #define CHARSET                  LSI_REGNAME_LMBCS
   #define CHARTYPE                 LSPLTCHAR
   #define getString()              getPltString()        
   #define getStringArray           getPltStringArray
   #define LIT_STR(x)               (LSPLTSTR) x  // Some compilers give a warning if no cast

#else

   // Handle PLATFORM / ASCII strings
   typedef LSXPltString             LSXString;
   typedef LSXPltStringArray        LSXStringArray;
   #define CHARSET                  LSI_REGNAME_PLATFORM
   #define CHARTYPE                 LSPLTCHAR
   #define getString()              getPltString()
   #define getStringArray           getPltStringArray
   #define LIT_STR(x)               (LSPLTSTR) x  // Some compilers give 
                                                  // a warning if no cast
#endif

/*********************************************************************/
/*   These defines segment the address space for string ids - your choice      */

//{{LSX_AUTHOR_CODE_Min_Error_Code
#define LSXBASE_MIN_ERROR_CODE  20001   /* your choice >20000 */
//}}

#define LSX_FIRST_USER_ERROR_CODE   (LSXBASE_MIN_ERROR_CODE+1)

// #define's for your error messages go here, following this model:

//{{LSX_AUTHOR_CODE_Error_Messages
#define ERR_SYSTEMCHECK_INIT_SYSTEMCHECK_FAILED     (LSX_FIRST_USER_ERROR_CODE+2)
#define LSXBASE_ERR_MAX_ERROR_CODE  (LSX_FIRST_USER_ERROR_CODE+2)
//}}



/*********************************************************************/

#define N_SYSTEMINFO_DISKCHECK_ARGS         2
#define N_SYSTEMINFO_NEW_ARGS         1
#define N_SYSTEMINFO_SYSTEMCHECK_ARGS         1



/*********************************************************************/
/*   Constants Exposed to LotusScript                                */


/*********************************************************************/

//{{LSX_AUTHOR_CODE_Global_Functions
//}}

#endif   // #if !defined (LSXAPPLX_H)

