/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: SystemInfo.hpp

   Description:
      Class definition for scriptable "SystemInfo" object

\*==============================================================================*/
#if !defined (SYSTEMINFO_HPP)
#define SYSTEMINFO_HPP

//{{LSX_AUTHOR_CODE_Include1
//}}

#include "lsxapplx.h"
#include "lsxbase.hpp"
#include "lsxsess.hpp"

class SystemInfo;

typedef LSXObjectArray<SystemInfo, CSYSTEMCHECK_SYSTEMINFO_ID> SystemInfoArray;

//{{LSX_AUTHOR_CODE_Include2
//}}

// forward references to other classes


class SystemInfo : public LSXBase
//{{LSX_AUTHOR_CODE_Additional_Base_Classes
//}}
{
   protected:

      // Data members exposed to LotusScript via Get/Set Prop (access functions inlined below)
      LSSLONG m_FreeDiskSpace;
      LSSSHORT m_OSBuildNumber;
      LSSSHORT m_OSMinorVersion;
      LSXString m_OSPlatform;
      LSSSHORT m_OSVersion;
      LSXString m_ProcessorType;
      LSSLONG m_TotalDiskSpace;
      LSSLONG m_TotalPhysicalMemory;

      //{{LSX_AUTHOR_CODE_Protected_Internal
      //}}

   private:

      //{{LSX_AUTHOR_CODE_Private_Internal
      //}}

      // These are private because they are unimplemented and we need to prevent
      // the compiler from creating default versions.
      SystemInfo & operator = (SystemInfo&);
      SystemInfo (const SystemInfo&);
      SystemInfo();

   public:

      // This constructor is called when the script "new"s one or calls
      // a function like "CreateSystemInfo" on the container class.
      SystemInfo( LSPTR(LSXLsiSession) pContainer);

      // This constructor is used by a derived class to initialize its parent
      SystemInfo(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer );

      virtual ~SystemInfo();


      // Methods exposed to LotusScript
      void DiskCheck ( LSXString Drive  );
      void SystemCheck (  );

      // Event-Raising methods

      
      // Helper functions - not exposed to LotusScript

      LSPTR(LSXLsiSession) LSXGetSession() const
      { 
         return ((LSPTR(LSXLsiSession)) pContainerObject)->LSXGetSession(); 
      }

      //{{LSX_AUTHOR_CODE_Public_Internal (not exposed to LotusScript)
      //}}

      // Low-level calls defined in iSystemInfo.CPP.
      virtual LSSTATUS LSXDispatchMethod(PLSADTMSGMETHOD args);
      virtual LSSTATUS LSXGetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);
      virtual LSSTATUS LSXSetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);


      // Property Gets and Sets for data members exposed to LotusScript
      inline LSSLONG GetFreeDiskSpace() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_FreeDiskSpace
         //}}

         return m_FreeDiskSpace;
      }
      inline void SetFreeDiskSpace(const LSSLONG FreeDiskSpace)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_FreeDiskSpace
         //}}
         m_FreeDiskSpace = FreeDiskSpace;
      }

      inline LSSSHORT GetOSBuildNumber() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_OSBuildNumber
         //}}

         return m_OSBuildNumber;
      }
      inline void SetOSBuildNumber(const LSSSHORT OSBuildNumber)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_OSBuildNumber
         //}}
         m_OSBuildNumber = OSBuildNumber;
      }

      inline LSSSHORT GetOSMinorVersion() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_OSMinorVersion
         //}}

         return m_OSMinorVersion;
      }
      inline void SetOSMinorVersion(const LSSSHORT OSMinorVersion)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_OSMinorVersion
         //}}
         m_OSMinorVersion = OSMinorVersion;
      }

      inline const LSXString& GetOSPlatform() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_OSPlatform
         //}}

         return m_OSPlatform;
      }
      inline void SetOSPlatform(const LSXString& OSPlatform)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_OSPlatform
         //}}
         m_OSPlatform = OSPlatform;
      }

      inline LSSSHORT GetOSVersion() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_OSVersion
         //}}

         return m_OSVersion;
      }
      inline void SetOSVersion(const LSSSHORT OSVersion)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_OSVersion
         //}}
         m_OSVersion = OSVersion;
      }

      inline const LSXString& GetProcessorType() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_ProcessorType
         //}}

         return m_ProcessorType;
      }
      inline void SetProcessorType(const LSXString& ProcessorType)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_ProcessorType
         //}}
         m_ProcessorType = ProcessorType;
      }

      inline LSSLONG GetTotalDiskSpace() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_TotalDiskSpace
         //}}

         return m_TotalDiskSpace;
      }
      inline void SetTotalDiskSpace(const LSSLONG TotalDiskSpace)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_TotalDiskSpace
         //}}
         m_TotalDiskSpace = TotalDiskSpace;
      }

      inline LSSLONG GetTotalPhysicalMemory() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_TotalPhysicalMemory
         //}}

         return m_TotalPhysicalMemory;
      }
      inline void SetTotalPhysicalMemory(const LSSLONG TotalPhysicalMemory)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_TotalPhysicalMemory
         //}}
         m_TotalPhysicalMemory = TotalPhysicalMemory;
      }

      //{{LSX_AUTHOR_CODE_Inlines
      //}}
};

//{{LSX_AUTHOR_CODE_Other
//}}

#endif   //   #if !defined (SYSTEMINFO_HPP)

