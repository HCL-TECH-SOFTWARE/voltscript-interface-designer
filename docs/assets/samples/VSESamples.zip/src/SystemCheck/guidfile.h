/*========================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: guidfile.h

   Description:
      This file contains YOUR GUID for use in your LSX.

      After acquiring the GUID, you should identify its constituent
      components as shown below.

\*========================================================================*/

#if !defined (GUIDFILE_H)
#define GUIDFILE_H

/*
   Suppose you have  54AEFC34-AD25-11d0-8916-00805F621FB7  as your GUID
*/

/* ---------------------------------------------------------------------------
   GUIDs - Globally Unique IDs
   --------------------------------------------------------------------------

   NOTE: If you use the macro

         DEFINE_GUID(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8)

         supplied by the OLE header files, the mapping of parameters to
         ordering in the GUID string you see in the Registry is:

            l        w1   w2   b1b2 b3b4b5b6b7b8
            |        |    |    | |  | | | | | |
            54AEFC34-AD25-11d0-8916-00805F621FB7

   ---------------------------------------------------------------------------
*/
/* ---------------------------------------------------------------------------
   #defines for the pieces of a GUID
*/

// your GUID is 54AEFC34-AD25-11d0-8916-00805F621FB7

#define LSX_YOUR_GUID_BASE_UL     ((unsigned long) 0x54AE0000)
#define LSX_YOUR_GUID_OFFSET_US   0xFC34

#define LSX_GUID_D2  0xAD25
#define LSX_GUID_D3  0x11d0
#define LSX_GUID_D41 0x89
#define LSX_GUID_D42 0x16
#define LSX_GUID_D43 0x00
#define LSX_GUID_D44 0x80
#define LSX_GUID_D45 0x5F
#define LSX_GUID_D46 0x62
#define LSX_GUID_D47 0x1F
#define LSX_GUID_D48 0xB7

//
// Note: these all refer to YOUR GUID base - which MUST not conflict !!!
//                        ********               ********

// even though we don't expose the Session class we still need a GUID for it

DEFINE_LSX_GUID(c_Session, LSX_ID_LSXBase + CSYSTEMCHECK_SESSION_ID);
DEFINE_LSX_GUID(c_SystemInfo, LSX_ID_LSXBase + CSYSTEMCHECK_SYSTEMINFO_ID);

#endif   //   #if !defined (GUIDFILE_H)