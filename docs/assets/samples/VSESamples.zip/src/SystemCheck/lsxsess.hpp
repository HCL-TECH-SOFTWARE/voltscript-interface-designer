/*========================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: lsxsess.hpp

   Description:
      Class definition for scriptable Session object

      A single instance of this class is instantiated upon execution of the USELSX
      statement.  It is destroyed when the LSX is unloaded.

\*========================================================================*/

#if !defined(LSXSESS_HPP)
#define LSXSESS_HPP

//{{LSX_AUTHOR_CODE_Include
//}}

#if !defined(LSXBASE_HPP)
#include "lsxbase.hpp"
#endif

/*******************************************************************
*
*  Class definition for SystemCheck Session object
*/

// Needed for the following forward references
#include "textstr.h"

// list forward references to other application classes used here
class SystemInfo;
typedef LSXObjectArray<SystemInfo, CSYSTEMCHECK_SYSTEMINFO_ID> SystemInfoArray;

class LSXLsiSession : public LSXBase
{
   protected:

      //{{LSX_AUTHOR_CODE_Protected_Internal
      //}}

   private:

      // Keep track of all the classes that are contained by this
      // session, by default.  No need to destinguish their type
      // because the containment is not part of the object model, 
      // just an extra safety measure for cleanup purposes

      LSPTR(LSXBase)   ContainedObjectList;

      // These are private to prevent people from calling them

      LSXLsiSession & operator = (LSXLsiSession&);
      LSXLsiSession (const LSXLsiSession&);
      LSXLsiSession();

      //{{LSX_AUTHOR_CODE_Private_Internal
      //}}

   public:

      LSXLsiSession(LShINSTANCE hinst);
      virtual ~LSXLsiSession();

      LSPTR(LSXLsiSession) LSXGetSession() { return this; }

      // These are methods of the base class that are being overridden

      virtual void ContainedObjectCreated(LSPTR(LSXBase) pContained)
      {
         LSXAddToList(pContained, (LSPTR(LSPTR(LSXBase))) &ContainedObjectList);
      }
      virtual void ContainedObjectDestroyed(LSPTR(LSXBase) pContained)
      {
         LSXRemoveFromList(pContained, (LSPTR(LSPTR(LSXBase))) &ContainedObjectList);
      }

      virtual LSSTATUS LSXDispatchMethod(PLSADTMSGMETHOD args){ return LSX_OK; }
      virtual LSSTATUS LSXGetProp(PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param){ return LSX_OK; }
      virtual LSSTATUS LSXSetProp(PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param){ return LSX_OK; }

     //{{LSX_AUTHOR_CODE_Public_Internal
     //}}
};

//{{LSX_AUTHOR_CODE_Other
//}}

#endif   //   #if !defined (LSXSESS_HPP)

