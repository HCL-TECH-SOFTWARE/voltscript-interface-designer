/* ======================================================================== *\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: textstr.h

   Description:
      The contents of this file will be very different for each different
      client application (LSX).  It contains client application specific
      definitions.
      However, the structure of the file will essentially be the same.
      The file contains #define's for each of the clients class elements
      (class names, property names, method names, event names, etc.).

\*========================================================================*/

#if !defined (TEXTSTR_H)
#define TEXTSTR_H

/*
   These constants segment the address space for string ids.  If two LSXs
   are being used in the same script and the ids for the elements overlap,
   you will get a USELSX error when the LotusScript host attempts to load
   the 2nd LSX.  Use the Project document in the Wizard to change this
   number.  Also, keep in mind that whenever this number is changed, all
   scripts that use the LSX must be recompiled.
*/

const LSUSHORT LSXBASE_NAMES = 300; // Where to start numbering ids for this LSX


const LSUSHORT CCUSTOMER_NOCLASS_ID = CNOTES_CLASS_LAST_ID;

// even though we don't expose the SESSION object, it needs an ID

const LSUSHORT CCUSTOMER_SESSION_ID = CCUSTOMER_NOCLASS_ID+1;

const LSUSHORT CCUSTOMER_CUSTOMER_ID = (CCUSTOMER_NOCLASS_ID+2);
const LSUSHORT CCUSTOMER_COLLCUST_ID = (CCUSTOMER_NOCLASS_ID+3);


const LSUSHORT LSX_FIRST_CLASS = CNOTES_CLASS_FIRST_ID;
const LSUSHORT LSX_LAST_CLASS  = CCUSTOMER_COLLCUST_ID;

#if defined (OLE_PLATFORM)

// this class id is for the hidden OLE Session object

const LSUSHORT LSX_OLE_CLASS = LSX_LAST_CLASS +1;

// since we don't expose the SESSION object, we need to use the top-level
// class ID for OLE automation

const LSUSHORT LSX_OLEMAIN_CLASS = CCUSTOMER_COLLCUST_ID;

#endif   // (OLE_PLATFORM)


/* for methods/properties which return objects */
#define LSX_CLASS_RET(x)        (DT_CLIENT_OBJECT(x))

/* for methods which take adt arguments        */
#define LSX_CLASS_ARG(x)        (LSX_CLASS_RET(x))

/* for collection class registration           */
#define LSX_COLL_CLASS_ITEM(x)  (LSX_CLASS_RET(x))

/*
*  Class method/property/event etc names are #define'd beginning
*  with CCUSTOMER, and are incremented up from LSXBASE_NAMES.
*
*/
#define CCUSTOMER_CUSTOMERPROP_ACCTNUMBER         (LSXBASE_NAMES+4)
#define CCUSTOMER_CUSTOMERPROP_ADDRESS         (LSXBASE_NAMES+2)
#define CCUSTOMER_CUSTOMERPROP_NAME         (LSXBASE_NAMES+1)
#define CCUSTOMER_CUSTOMERPROP_PHONENUMBER         (LSXBASE_NAMES+3)
#define CCUSTOMER_COLLCUSTPROP_CURRCUSTINDEX         (LSXBASE_NAMES+7)
#define CCUSTOMER_COLLCUSTPROP_NUMCUSTOMERS         (LSXBASE_NAMES+6)

#define CCUSTOMER_CUSTOMERMETHOD_NEW       (LSXBASE_NAMES+5)
#define CCUSTOMER_COLLCUSTMETHOD_CLOSECUSTOMERS       (LSXBASE_NAMES+10)
#define CCUSTOMER_COLLCUSTMETHOD_GETFIRSTCUSTOMER       (LSXBASE_NAMES+13)
#define CCUSTOMER_COLLCUSTMETHOD_GETNEXTCUSTOMER       (LSXBASE_NAMES+11)
#define CCUSTOMER_COLLCUSTMETHOD_GETPREVCUSTOMER       (LSXBASE_NAMES+12)
#define CCUSTOMER_COLLCUSTMETHOD_NEW       (LSXBASE_NAMES+8)
#define CCUSTOMER_COLLCUSTMETHOD_OPENCUSTOMERS       (LSXBASE_NAMES+9)




#endif   // #if !defined (TEXTSTR_H)