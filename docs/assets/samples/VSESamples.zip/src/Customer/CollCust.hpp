/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: CollCust.hpp

   Description:
      Class definition for scriptable "CollCust" object

\*==============================================================================*/
#if !defined (COLLCUST_HPP)
#define COLLCUST_HPP

//{{LSX_AUTHOR_CODE_Include1
//}}

#include "lsxapplx.h"
#include "lsxbase.hpp"
#include "lsxsess.hpp"

class CollCust;

typedef LSXObjectArray<CollCust, CCUSTOMER_COLLCUST_ID> CollCustArray;

//{{LSX_AUTHOR_CODE_Include2

typedef struct
{
	char	custName[32];
	char	custAddress[64];
	char	custPhone[16];
	char	custNumber[16];
}	FileRecord, * LPFileRecord;

//}}

// forward references to other classes
class Customer;
typedef LSXObjectArray<Customer, CCUSTOMER_CUSTOMER_ID> CustomerArray;

class CollCust : public LSXBase
//{{LSX_AUTHOR_CODE_Additional_Base_Classes
//}}
{
   protected:

      //Track all objects contained by this object.
      LSPTR(Customer) CustomerList;

      // Data members exposed to LotusScript via Get/Set Prop (access functions inlined below)
      LSSSHORT m_CurrCustIndex;
      LSSSHORT m_NumCustomers;

      //{{LSX_AUTHOR_CODE_Protected_Internal
		LSPTR(Customer)	m_CurrCustomer;
      //}}

   private:

      //{{LSX_AUTHOR_CODE_Private_Internal
      LSBOOL   alreadyconnected;
		FILE*    hfile;

  		LSBOOL	ReadOneRecord(LSPTR(FileRecord) fr);
      void     CreateNewCustomer(LSPTR(FileRecord) filerecord);

      //}}

      // These are private because they are unimplemented and we need to prevent
      // the compiler from creating default versions.
      CollCust & operator = (CollCust&);
      CollCust (const CollCust&);
      CollCust();

   public:

      // This constructor is called when the script "new"s one or calls
      // a function like "CreateCollCust" on the container class.
      CollCust( LSPTR(LSXLsiSession) pContainer);

      // This constructor is used by a derived class to initialize its parent
      CollCust(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer );

      virtual ~CollCust();


      // Methods exposed to LotusScript
      void CloseCustomers (  );
      Customer& GetFirstCustomer (  );
      Customer& GetNextCustomer (  );
      Customer& GetPrevCustomer (  );
      LSSSHORT OpenCustomers ( LSXString& FileName  );

      // Event-Raising methods

      
      // Helper functions - not exposed to LotusScript

      LSPTR(LSXLsiSession) LSXGetSession() const
      { 
         return ((LSPTR(LSXLsiSession)) pContainerObject)->LSXGetSession(); 
      }

      //{{LSX_AUTHOR_CODE_Public_Internal (not exposed to LotusScript)
      //}}

      // Low-level calls defined in iCollCust.CPP.
      virtual LSSTATUS LSXDispatchMethod(PLSADTMSGMETHOD args);
      virtual LSSTATUS LSXGetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);
      virtual LSSTATUS LSXSetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);
      void LSXAddToCustomerList(LSPTR(Customer) c);
      void LSXRemoveFromCustomerList(LSPTR(Customer) c);

      virtual LSSTATUS LSXCollectOpen(PLSADTMSGCOLLECTION args);
      virtual LSSTATUS LSXCollectItem(PLSADTMSGCOLLECTITEM args);
      virtual LSSTATUS LSXCollectNext(PLSADTMSGCOLLECTION args);
      virtual LSSTATUS LSXCollectClose(PLSADTMSGCOLLECTION args);

      Customer& CollectionOpen(LSUSHORT& Found, LSPVOID& Start, LSPVOID& Curr, LSPVOID& Last);
      Customer& CollectionNext(LSUSHORT& Found, LSPVOID& Start, LSPVOID& Curr, LSPVOID& Last);
      Customer& CollectionItem(LSXString Index, LSUSHORT& Found);
      void CollectionClose(LSPVOID& Start, LSPVOID& Curr, LSPVOID& Last);


      // Property Gets and Sets for data members exposed to LotusScript
      inline LSSSHORT GetCurrCustIndex() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_CurrCustIndex
         //}}

         return m_CurrCustIndex;
      }
      inline void SetCurrCustIndex(const LSSSHORT CurrCustIndex)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_CurrCustIndex
         //}}
         m_CurrCustIndex = CurrCustIndex;
      }

      inline LSSSHORT GetNumCustomers() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_NumCustomers
         //}}

         return m_NumCustomers;
      }
      inline void SetNumCustomers(const LSSSHORT NumCustomers)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_NumCustomers
         //}}
         m_NumCustomers = NumCustomers;
      }

      //{{LSX_AUTHOR_CODE_Inlines
      //}}
};

//{{LSX_AUTHOR_CODE_Other
//}}

#endif   //   #if !defined (COLLCUST_HPP)

