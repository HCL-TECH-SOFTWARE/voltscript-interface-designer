/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: iCustomer.cpp

   Description:
      Class methods to support LSX architecture.

\*============================================================================*/

#include "Customer.hpp"

#include "CollCust.hpp"

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 *   Expanded class support (only if this class is expanded)
 *
 *******************************************************************************/
/*
   Generate an on the fly property id for an arbitrary string.
   Each name and id is cached. Ids start after the highest
   registered property code for this class, and are incremented
   on each new query.

   All properties are assumed to be variants. When LS calls us
   back with a special property id, we retrieve the saved name
   and treat it as if it were a property item name in the object.
*/

LSSTATUS Customer:: LSXQueryBindMember(PLSADTMSGBINDMEMBER args)
{
   int                  len;
   LSBOOL               found=LSFALSE;
   LShINSTANCE          hLSInstance=this->LSXGetInstance();
   LSPTR(LSXPROPERTY)   pProp = this->ExpandedNames;
   LSPLTSTR             propName = (char *)args->MemberName.Str;

   // Fill in the struct LSADTMSGBINDMEMBER (\lsx\inc\lsilsx.h)

   // In this release, we are only providing an example of late binding
   // for properties (not methods)

   args->Type = LSI_ADT_MEMBER_PROP;   // type is always PROPERTY (here)

   // If you are also exposing methods, you will need to determine which
   // method the user has attempted to use from the exposed name in
   // args->MemberName.Str and have appropriate code to handle the call.
   // You would also set
   //    args->Type = LSI_ADT_MEMBER_METH;

   args->AdtClsIdTable=(LSADTCLSIDTBL)::LSXGetClassIDTable();

   // Flags contains any LSI_ADTPROP_* items you want applied to the property

   args->Info.Prop.Flags = LSI_ADTPROP_NONE;

   // always return a variant and let LS do the conversion

   args->Info.Prop.DataType = LSI_DT_VARIANT;

   // see if this name already exists, return that id
   while ((pProp) && (! found))
   {
      if (NDSTRICMP((char *)pProp->name, (char *)propName) == 0)
      {
         found = LSTRUE;   // found it - set the id and return

         args->Info.Prop.ID = pProp->id;
      }
      else pProp = pProp->next;
   }

   if (!found)
   {
      // not found, create new entry in the list of property items

      pProp = ::new LSXPROPERTY;
      memset(pProp, 0, sizeof(LSXPROPERTY));

      // Link it
      pProp->next = this->ExpandedNames;
      this->ExpandedNames = pProp;

      // Set the id to this.
      pProp->id = LSADTPROPID(pProp);

      // copy the name to the new list item
      len = strlen((LSPLTSTR)args->MemberName.Str) + 1;
      pProp->name = (LSPLTSTR) ::operator new(len);
      memmove(pProp->name, args->MemberName.Str, len);
      args->Info.Prop.ID = pProp->id;
   }
   return LSX_OK;
}

/**********************************************************************/


/*******************************************************************************
 *
 *   Containment support (only if this class is a container)
 *
 *******************************************************************************/

/*******************************************************************************
 *
 *   Collection support (only if this class is a collection)
 *
 *******************************************************************************/

/*******************************************************************************
 *
 *   Property Dispatching
 *
 *******************************************************************************/

LSSTATUS Customer:: LSXGetProp(PLSADTINSTDESC pInstDesc, PLSADTMSGPROP param)
{
   LSSTATUS     stat = LSX_OK;
   LSADTPROPID  id   = param->idProp;

   LSXValue Val(param->valProp, LsiInst);

   switch (id)
   {
   case CCUSTOMER_CUSTOMERPROP_ACCTNUMBER:
      Val.set(GetAcctNumber());
      break;

   case CCUSTOMER_CUSTOMERPROP_ADDRESS:
      Val.set(GetAddress());
      break;

   case CCUSTOMER_CUSTOMERPROP_NAME:
      Val.set(GetName());
      break;

   case CCUSTOMER_CUSTOMERPROP_PHONENUMBER:
      Val.set(GetPhoneNumber());
      break;

   default:
      PLSXPROPERTY   pProp;

      // See if this is an expanded property
      pProp = FindPropById(this->ExpandedNames, id);
      if (pProp)
      {
         /*
            This is the "expanded" property feature. If all
            is well, we have already saved the "property" name
            in a member variable. Now we just have to find an
            item of that name, and return its value.
         */
         stat = this->LSXRetrievePropertyValue(param->valProp, pProp);
      }
      else
      {
      stat = LSI_ERR_UNAVAIL;
      assert(LSFALSE);
      }

      break;
   }

   return stat;
}

//------------------------------------------------------------------------------

LSSTATUS Customer:: LSXSetProp(PLSADTINSTDESC pInstDesc, PLSADTMSGPROP param)
{
   LSSTATUS     stat = LSX_OK;
   LSADTPROPID  id   = param->idProp;

   LSXValue Val(param->valProp, LsiInst);

   switch (id)
   {
   case CCUSTOMER_CUSTOMERPROP_ACCTNUMBER:
      SetAcctNumber(Val.getString());
      break;

   case CCUSTOMER_CUSTOMERPROP_ADDRESS:
      SetAddress(Val.getString());
      break;

   case CCUSTOMER_CUSTOMERPROP_NAME:
      SetName(Val.getString());
      break;

   case CCUSTOMER_CUSTOMERPROP_PHONENUMBER:
      SetPhoneNumber(Val.getString());
      break;

   default:
      PLSXPROPERTY   pProp;

      pProp = FindPropById(this->ExpandedNames, id);
      if (pProp)
      {
         /*
            This is the "expanded" property feature. If all is well, we have
            already saved the "property" name in a member variable during the
            LSXQueryBindMember call. Now we just have to find (or create) an
            item of that name, and set its value.
         */
         stat = this->LSXStorePropertyValue(param->valProp, pProp);
      }
      else
      {
      stat = LSI_ERR_UNAVAIL;
      assert(LSFALSE);
      }

      break;
   }

   return stat;
}
/***********************************************************************/

LSSTATUS Customer:: LSXRetrievePropertyValue(
                     PLSVALUE       pValue,
                     PLSXPROPERTY   pProp)
{
   if ( ! pProp->hasValue )
   {
      // Value has not been set yet...
      this->LSXRaiseError(ERR_CUSTOMER_EXPAND_PROP_NOT_SET);
   }

   switch (pProp->Value.Type)
   {
   case LSVT_EMPTY:      case LSVT_NULL:      case LSVT_SHORT:
   case LSVT_LONG:       case LSVT_SINGLE:    case LSVT_DOUBLE:
   case LSVT_CURRENCY:   case LSVT_DATE:      case LSVT_ERROR:
   case LSVT_BOOLEAN:
      // These values we can just copy
      *pValue = pProp->Value;
      break;

   case LSVT_STRING:
      // Create an LSI string to return ...
      pValue->vString =
            LSICALL(StringCreate)(pProp->Value.vString,
                              LSIStringSize(pProp->Value.vString),
                              LSI_REGNAME_PLATFORM);
      pValue->Type = LSVT_STRING;
      break;

   default:
      // not good - we will not store other values...
      return LSI_ERR_ABORT;
      break;
   }
   return LSX_OK;
}

/***********************************************************************/

LSSTATUS Customer:: LSXStorePropertyValue(
                     PLSVALUE       pValue,
                     PLSXPROPERTY   pProp)
{
   pProp->Value = *pValue;

   // We don't care about 'from variant' flag
   pProp->Value.Type = LSVALTYPE(pValue->Type & ~LSVT_FROMVAR);

   switch (pProp->Value.Type)
   {
   case LSVT_EMPTY:      case LSVT_NULL:      case LSVT_SHORT:
   case LSVT_LONG:       case LSVT_SINGLE:    case LSVT_DOUBLE:
   case LSVT_CURRENCY:   case LSVT_DATE:      case LSVT_ERROR:
   case LSVT_BOOLEAN:
      // These values we can just copy
      break;

   case LSVT_STRING:
      // reference count the string...
      pProp->Value.vString = LSICALL(StringRef(pProp->Value.vString));
      break;

   default:
      // not good - we will not store other values...
      return LSI_ERR_ABORT;
   }
   pProp->hasValue = LSTRUE;
   return LSX_OK;
}

LSSTATUS Customer:: LSXEnumMemberBegin(LShINSTANCE hInst,
                                 PLSADTMSGENUMMEMBER pEnumMember)
{
   pEnumMember->MemberName = LSNULL;
   pEnumMember->pEnumState = LSPVOID(0);
   return LSX_OK;
}

LSSTATUS Customer:: LSXEnumMemberEnd(LShINSTANCE hInst,
                               PLSADTMSGENUMMEMBER pEnumMember)
{
   pEnumMember->MemberName = LSNULL;
   pEnumMember->pEnumState = LSPVOID(0);
   return LSX_OK;
}

LSSTATUS Customer:: LSXEnumMemberNext(LShINSTANCE hInst,
                                PLSADTMSGENUMMEMBER pEnumMember)
{
   /*
      This is SAMPLE code showing how you MIGHT implement a response
      to a request from LotusScript for information about your Expanded
      Class items.

      This code would require some registration tables to support the
      accesses to  other_gExpMethods[i]   and   other_gExpProperties[i].
   */
   int i = (int)(LSULONG)(pEnumMember->pEnumState);

   pEnumMember->pEnumState = LSPVOID(LSULONG(i + 1));
   switch (pEnumMember->Type)
   {
      case LSI_ADT_MEMBER_METH:
      {
         break;
      }
      case LSI_ADT_MEMBER_PROP:
      {
         break;
      }
   }
   pEnumMember->MemberName = LSNULL;
   return LSI_ERR_ENUM_DONE;
}


/*******************************************************************************
 *
 *   Method Dispatching and Argument Parsing
 *
 *******************************************************************************/
LSSTATUS Customer:: LSXDispatchMethod(PLSADTMSGMETHOD args)
{
   LSSTATUS stat = LSX_OK;

      stat = LSI_RTE_SubOrFunctionNotDefined;
      assert (LSFALSE);
   return stat;
}
/*******************************************************************************
 *
 *   Event Raising Method Definitions
 *
 *******************************************************************************/

