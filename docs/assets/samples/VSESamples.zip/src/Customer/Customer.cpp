/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: Customer.cpp

   Description:
      Implementation of methods for the scriptable "Customer" object

\*============================================================================*/

//{{LSX_AUTHOR_CODE_Include_1
//}}

#include "Customer.hpp"

// includes for the objects defined in your LSX
#include "CollCust.hpp"

//{{LSX_AUTHOR_CODE_Include_2
//}}

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 * Constructors/Destructors
 *
 ******************************************************************************/
// This constructor is called when the script 'new's one or calls
// CreateCustomer on the container class.

Customer:: Customer( LSPTR(CollCust) pContainer, LSXString Name, LSXString Address, LSXString Phone, LSXString CustNumber)
   : LSXBase((LSPLTSTR)"Customer", pContainer->LSXGetInstance(), CCUSTOMER_CUSTOMER_ID, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init1
   //}}
   ExpandedNames(LSNULL),
   m_AcctNumber(CustNumber),
   m_Address(Address),
   m_Name(Name),
   m_PhoneNumber(Phone)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init1
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor1
   //}}

   // add object to Container's list
   if (pContainer)
      pContainer->LSXAddToCustomerList(this);
}

// ------------------------------------------------------------------------------

// This version of the constructor is called by a derived class for its 
// constructor initialization.

Customer:: Customer(LSUSHORT classId, LSPTR(CollCust) pContainer, LSXString Name, LSXString Address, LSXString Phone, LSXString CustNumber )
   : LSXBase((LSPLTSTR)"Customer", pContainer->LSXGetInstance(), classId, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init2
   //}}
   ExpandedNames(LSNULL),
   m_AcctNumber(CustNumber),
   m_Address(Address),
   m_Name(Name),
   m_PhoneNumber(Phone)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init2
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor2
   //}}

}

//------------------------------------------------------------------------------
//{{LSX_AUTHOR_CODE_Additional_Constructors
//}}
//------------------------------------------------------------------------------

Customer:: ~Customer()
{
   //{{LSX_AUTHOR_CODE_Destructor
   //}}

      /*
      if this is an Expanded class, then walk down the ExpandedNames list
      and free all the Expanded property items.
   */

   if (this->ExpandedNames)
   {
      LSPTR(LSXPROPERTY) pProp = this->ExpandedNames;
      LSPTR(LSXPROPERTY) pTmp;
      while (pProp)
      {
         delete pProp->name;
         pTmp = pProp->next;
         if (pProp->Value.Type == LSVT_STRING)
         {
            LSICALL(StringDeref(pProp->Value.vString));
         }
         delete pProp;
         pProp = pTmp;
      }
      this->ExpandedNames=LSNULL;
   }


   // remove from Container's child list
   if (pContainerObject)
      ((LSPTR(CollCust))pContainerObject)->LSXRemoveFromCustomerList(this);

}

/*******************************************************************************
 *
 * Method Definitions for methods that are exposed to LotusScript
 *
 *******************************************************************************/

/*******************************************************************************
 *
 * Internal Method Definitions
 *
 *******************************************************************************/
//{{LSX_AUTHOR_CODE_Internal_Methods
//}}

