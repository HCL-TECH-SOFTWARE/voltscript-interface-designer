/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: iCollCust.cpp

   Description:
      Class methods to support LSX architecture.

\*============================================================================*/

#include "CollCust.hpp"

#include "Customer.hpp"

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 *   Expanded class support (only if this class is expanded)
 *
 *******************************************************************************/

/*******************************************************************************
 *
 *   Containment support (only if this class is a container)
 *
 *******************************************************************************/
void CollCust:: LSXAddToCustomerList(LSPTR(Customer) c)
{
   LSXAddToList((LSPTR(LSXBase))c, (LSPTR(LSPTR(LSXBase)))&CustomerList);
}

void CollCust:: LSXRemoveFromCustomerList(LSPTR(Customer) c)
{
   LSXRemoveFromList((LSPTR(LSXBase))c,(LSPTR(LSPTR(LSXBase)))&CustomerList);
}
/*******************************************************************************
 *
 *   Collection support (only if this class is a collection)
 *
 *******************************************************************************/
LSSTATUS CollCust::LSXCollectOpen(PLSADTMSGCOLLECTION args)
{
   LSXValue Item(&args->Item, LsiInst);

   args->Found = 1;

   Customer& FirstItem = CollectionOpen(args->Found, args->Start, args->Curr, args->Last);

   if (args->Found)
      Item.set(FirstItem);

   return LSX_OK;
}

//------------------------------------------------------------------------------

LSSTATUS CollCust::LSXCollectItem(PLSADTMSGCOLLECTITEM args)
{
   LSXValue Item(args->Item, LsiInst);
   LSXValue Index(args->Index, LsiInst);

   args->Found = 1;

   Customer& FoundItem = CollectionItem( Index.getString(), args->Found );

   if (args->Found)
      Item.set(FoundItem);

   return LSX_OK;
}

//------------------------------------------------------------------------------

LSSTATUS CollCust::LSXCollectNext(PLSADTMSGCOLLECTION args)
{
   LSXValue Item(&(args->Item), LsiInst);

   args->Found = 1;

   Customer& NextItem = CollectionNext(args->Found, args->Start, args->Curr, args->Last);

   if (args->Found)
      Item.set(NextItem);

   return LSX_OK;
}

//------------------------------------------------------------------------------

LSSTATUS CollCust::LSXCollectClose(PLSADTMSGCOLLECTION args)
{
      CollectionClose(args->Start, args->Curr, args->Last);

      return LSX_OK;
}

/*******************************************************************************
 *
 *   Property Dispatching
 *
 *******************************************************************************/

LSSTATUS CollCust:: LSXGetProp(PLSADTINSTDESC pInstDesc, PLSADTMSGPROP param)
{
   LSSTATUS     stat = LSX_OK;
   LSADTPROPID  id   = param->idProp;

   LSXValue Val(param->valProp, LsiInst);

   switch (id)
   {
   case CCUSTOMER_COLLCUSTPROP_CURRCUSTINDEX:
      Val.set(GetCurrCustIndex());
      break;

   case CCUSTOMER_COLLCUSTPROP_NUMCUSTOMERS:
      Val.set(GetNumCustomers());
      break;

   default:
      stat = LSI_ERR_UNAVAIL;
      assert(LSFALSE);
      break;
   }

   return stat;
}

//------------------------------------------------------------------------------

LSSTATUS CollCust:: LSXSetProp(PLSADTINSTDESC pInstDesc, PLSADTMSGPROP param)
{
   LSSTATUS     stat = LSX_OK;
   LSADTPROPID  id   = param->idProp;

   LSXValue Val(param->valProp, LsiInst);

   switch (id)
   {
   case CCUSTOMER_COLLCUSTPROP_CURRCUSTINDEX:
      SetCurrCustIndex(Val.getShort());
      break;

   case CCUSTOMER_COLLCUSTPROP_NUMCUSTOMERS:
      SetNumCustomers(Val.getShort());
      break;

   default:
      stat = LSI_ERR_UNAVAIL;
      assert(LSFALSE);
      break;
   }

   return stat;
}

/*******************************************************************************
 *
 *   Method Dispatching and Argument Parsing
 *
 *******************************************************************************/
LSSTATUS CollCust:: LSXDispatchMethod(PLSADTMSGMETHOD args)
{
   LSSTATUS stat = LSX_OK;

   // using the given method id, call the appropriate class method

   switch (args->idMeth)
   {
   case CCUSTOMER_COLLCUSTMETHOD_CLOSECUSTOMERS:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, SUB, LsiInst);

      
      
      //Execute the method
      CloseCustomers();
      
      }
      break;

   case CCUSTOMER_COLLCUSTMETHOD_GETFIRSTCUSTOMER:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      
      //Execute the method
      Customer& RetVal = GetFirstCustomer();

      //Set return value
      ArgList.setRetVal(RetVal);
      
      }
      break;

   case CCUSTOMER_COLLCUSTMETHOD_GETNEXTCUSTOMER:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      
      //Execute the method
      Customer& RetVal = GetNextCustomer();

      //Set return value
      ArgList.setRetVal(RetVal);
      
      }
      break;

   case CCUSTOMER_COLLCUSTMETHOD_GETPREVCUSTOMER:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      
      //Execute the method
      Customer& RetVal = GetPrevCustomer();

      //Set return value
      ArgList.setRetVal(RetVal);
      
      }
      break;

   case CCUSTOMER_COLLCUSTMETHOD_OPENCUSTOMERS:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXString FileName =  ArgList.getArg(1).getString();

      
      //Execute the method
      LSSSHORT RetVal = OpenCustomers(FileName);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      //Set byref arguments
      ArgList.setArg(1, FileName);
      }
      break;


   // list any other methods that you are exposing to the users of your LSX

   default:
      /*
      ** Either we have been passed
      **    (i) a bogus method id from LS, or,
      **   (ii) the method id of one of the parent class's methods (ie. this
      **        class is derived from a parent class).
      **
      ** If situation (i) then we need to determine why we have been passed
      ** the bad method id and fix the problem. This could occur if we changed
      ** the id's that we register with LS and did not tell LS at registration
      ** time that they had changed - by updating the version number.
      ** If you have changed the id's  you MUST recompile the script.
      **
      ** In that case, we should fail, thus:

         stat = LSI_RTE_SubOrFunctionNotDefined;
         assert (LSFALSE);

      ** If situation (ii) then we need to pass the method id on to the
      ** parent class dispatch method.  If the parent class is one of
      ** your own classes, you can code the call thus:

         stat = CollCust::LSXDispatchMethod(args);

      ** If the parent class is one of the Notes back-end classes, then
      ** we need to pass the method id and args block on to his dispatch
      ** method. ie. pretend we are LotusScript.

         stat = pADT->ClassControl(this->LSXGetInstance(),
                                  LSI_ADTMSG_METHOD,
                                  this->LSXGetADTInstDesc(),
                                  (LSPTR(void))args);

      ** In order to use this call successfully, we will need to have cached
      ** a pointer to the "real" corresponding Notes back-end object.
      ** For an example of how this is done, see the LSXBEPlus sample
      ** (NotesDbPlus.CPP & iNotesDbPlus.CPP)
      */

      stat = LSI_RTE_SubOrFunctionNotDefined;
      assert (LSFALSE);
      break;
   }

   return stat;
}
/*******************************************************************************
 *
 *   Event Raising Method Definitions
 *
 *******************************************************************************/

