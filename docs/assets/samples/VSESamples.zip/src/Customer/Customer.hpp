/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: Customer.hpp

   Description:
      Class definition for scriptable "Customer" object

\*==============================================================================*/
#if !defined (CUSTOMER_HPP)
#define CUSTOMER_HPP

//{{LSX_AUTHOR_CODE_Include1
//}}

#include "lsxapplx.h"
#include "lsxbase.hpp"
#include "lsxsess.hpp"

class Customer;

typedef LSXObjectArray<Customer, CCUSTOMER_CUSTOMER_ID> CustomerArray;

//{{LSX_AUTHOR_CODE_Include2
//}}

// forward references to other classes
class CollCust;
typedef LSXObjectArray<CollCust, CCUSTOMER_COLLCUST_ID> CollCustArray;

class Customer : public LSXBase
//{{LSX_AUTHOR_CODE_Additional_Base_Classes
//}}
{
   protected:

      // Data members exposed to LotusScript via Get/Set Prop (access functions inlined below)
      LSXString m_AcctNumber;
      LSXString m_Address;
      LSXString m_Name;
      LSXString m_PhoneNumber;

      //{{LSX_AUTHOR_CODE_Protected_Internal
      //}}

      /*
      ** If this is an "expanded" class, we will be queried for various
      ** property names before Get/Set operations. The Get/Set calls
      ** themselves only give us the (short) property id we return to
      ** it on the query call. We can't rely on getting a query
      ** immediately before the Get or Set (in fact, with statements like
      **    Customer1.f1 = Customer1.f2
      ** you get 2 queries then a Get then a Set).
      **
      ** This means that we have to cache all the names we are passed,
      ** return a unique id for each, then look up the name again on the
      ** Get or Set call.
      */

      LSPTR(LSXPROPERTY)  ExpandedNames;

   private:

      //{{LSX_AUTHOR_CODE_Private_Internal
      //}}

      // These are private because they are unimplemented and we need to prevent
      // the compiler from creating default versions.
      Customer & operator = (Customer&);
      Customer (const Customer&);
      Customer();

   public:

      // This constructor is called when the script "new"s one or calls
      // a function like "CreateCustomer" on the container class.
      Customer( LSPTR(CollCust) pContainer, LSXString Name , LSXString Address , LSXString Phone , LSXString CustNumber );

      // This constructor is used by a derived class to initialize its parent
      Customer(LSUSHORT classId, LSPTR(CollCust) pContainer, LSXString Name , LSXString Address , LSXString Phone , LSXString CustNumber  );

      virtual ~Customer();


      // Methods exposed to LotusScript


      // Event-Raising methods

      
      // Helper functions - not exposed to LotusScript

      LSPTR(LSXLsiSession) LSXGetSession() const
      { 
         return ((LSPTR(LSXLsiSession)) pContainerObject)->LSXGetSession(); 
      }

      //{{LSX_AUTHOR_CODE_Public_Internal (not exposed to LotusScript)
      //}}

      // Low-level calls defined in iCustomer.CPP.
      virtual LSSTATUS LSXDispatchMethod(PLSADTMSGMETHOD args);
      virtual LSSTATUS LSXGetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);
      virtual LSSTATUS LSXSetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);

      LSSTATUS LSXRetrievePropertyValue(PLSVALUE pValue, PLSXPROPERTY pProp);

      LSSTATUS LSXStorePropertyValue(PLSVALUE pValue, PLSXPROPERTY pProp);

      /*
      ** This virtual method is implemented only in classes which
      ** register themselves as "expandable", ie., they bind on
      ** the fly to arbitrary property/method names.
      */

      virtual LSSTATUS LSXQueryBindMember(PLSADTMSGBINDMEMBER args);

      virtual LSSTATUS LSXEnumMemberBegin
                           (LShINSTANCE hInst, PLSADTMSGENUMMEMBER pEnumMember);
      virtual LSSTATUS LSXEnumMemberNext
                           (LShINSTANCE hInst, PLSADTMSGENUMMEMBER pEnumMember);
      virtual LSSTATUS LSXEnumMemberEnd
                           (LShINSTANCE hInst, PLSADTMSGENUMMEMBER pEnumMember);


      // Property Gets and Sets for data members exposed to LotusScript
      inline const LSXString& GetAcctNumber() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_AcctNumber
         //}}

         return m_AcctNumber;
      }
      inline void SetAcctNumber(const LSXString& AcctNumber)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_AcctNumber
         //}}
         m_AcctNumber = AcctNumber;
      }

      inline const LSXString& GetAddress() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_Address
         //}}

         return m_Address;
      }
      inline void SetAddress(const LSXString& Address)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_Address
         //}}
         m_Address = Address;
      }

      inline const LSXString& GetName() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_Name
         //}}

         return m_Name;
      }
      inline void SetName(const LSXString& Name)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_Name
         //}}
         m_Name = Name;
      }

      inline const LSXString& GetPhoneNumber() const  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_PhoneNumber
         //}}

         return m_PhoneNumber;
      }
      inline void SetPhoneNumber(const LSXString& PhoneNumber)
      {
         //{{LSX_AUTHOR_CODE_PropertySet_PhoneNumber
         //}}
         m_PhoneNumber = PhoneNumber;
      }

      //{{LSX_AUTHOR_CODE_Inlines
      //}}
};

//{{LSX_AUTHOR_CODE_Other
//}}

#endif   //   #if !defined (CUSTOMER_HPP)
/*

The following tags extracted from your original file were not found
in the newly generated file, probably because their associated method,
property, or event was deleted.

//{{LSX_AUTHOR_CODE_PropertyGet_prop1
//}}
//{{LSX_AUTHOR_CODE_PropertySet_prop1
//}}
*/

