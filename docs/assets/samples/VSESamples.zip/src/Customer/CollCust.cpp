/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: CollCust.cpp

   Description:
      Implementation of methods for the scriptable "CollCust" object

\*============================================================================*/

//{{LSX_AUTHOR_CODE_Include_1
//}}

#include "CollCust.hpp"

// includes for the objects defined in your LSX
#include "Customer.hpp"

//{{LSX_AUTHOR_CODE_Include_2
//}}

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 * Constructors/Destructors
 *
 ******************************************************************************/
// This constructor is called when the script 'new's one or calls
// CreateCollCust on the container class.

CollCust:: CollCust( LSPTR(LSXLsiSession) pContainer)
   : LSXBase((LSPLTSTR)"CollCust", pContainer->LSXGetInstance(), CCUSTOMER_COLLCUST_ID, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init1
   //}}
   CustomerList(LSNULL),
   m_CurrCustIndex(0),
   m_NumCustomers(0)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init1
   ,alreadyconnected(LSFALSE)
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor1
   //}}

}

// ------------------------------------------------------------------------------

// This version of the constructor is called by a derived class for its 
// constructor initialization.

CollCust:: CollCust(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer )
   : LSXBase((LSPLTSTR)"CollCust", pContainer->LSXGetInstance(), classId, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init2
   //}}
   CustomerList(LSNULL),
   m_CurrCustIndex(0),
   m_NumCustomers(0)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init2
   ,alreadyconnected(LSFALSE)
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor2
   //}}

}

//------------------------------------------------------------------------------
//{{LSX_AUTHOR_CODE_Additional_Constructors
//}}
//------------------------------------------------------------------------------

CollCust:: ~CollCust()
{
   //{{LSX_AUTHOR_CODE_Destructor
   //}}

   

   LSXDeleteList(CustomerList);

}
/*******************************************************************************
 *
 * Collection support
 *
 * - To support the "ForAll" statement, and accessing the collection by index.
 *
 *******************************************************************************/

Customer& CollCust::CollectionOpen(LSUSHORT& Found, LSPVOID& Start, LSPVOID& Curr, LSPVOID& Last)
{
   // This method is called when the LotusScript "ForAll" statement is executed
   // on the collection.  The method should do any necessary initialization of
   // the collection and return the first element in the collection.

   // In the event of an empty or invalid collection, the Found argument should
   // be set to 0 and LotusScript will terminate the loop.

   // The Start, Curr, and Last arguments are for your own use in tracking
   // information about the iteration. LotusScript will preserve these values
   // and pass them back with each iteration.

   //{{LSX_AUTHOR_CODE_CollectionOpen

    if (m_NumCustomers <= 0)
       Found = LSFALSE;

    //Set Start/Curr for use in CollectionNext
    Start = CustomerList;
    Curr  = CustomerList;
    Last  = CustomerList;

    return *CustomerList;

   //}}
}

//------------------------------------------------------------------------------

Customer& CollCust::CollectionNext(LSUSHORT& Found, LSPVOID& Start, LSPVOID& Curr, LSPVOID& Last)
{
   // This method is called for each iteration of the "ForAll" loop.  The
   // method should return the next item in the collection.  The Start, Curr,
   // and Last fields should be set as desired and will be passed back in the
   // next time this method is called.

   // If there are no more items in the collection, the Found argument should be
   // set to 0 and any termination code should be executed.

   //{{LSX_AUTHOR_CODE_CollectionNext

   LSPTR(Customer) Current;

   Current = (LSPTR(Customer))(((LSPTR(LSXBase)) Last)->GetNextPtr());

   //Check to see if we are at the end of the list
   if (Current)
   {
      Found = 1;

      //Set Last for use in next iterations
      Last = Current;
   }
   else
   {
      Found = 0;
   }

   return *Current;

   //}}
}

//------------------------------------------------------------------------------

void CollCust::CollectionClose(LSPVOID& Start, LSPVOID& Curr, LSPVOID& Last)
{
   // This method is called if the iteration is terminated without exhausting the
   // collection, for example, due to an unhandled error, or the user exiting the
   // "For All" loop. Any necessary cleanup should be done here.

   //{{LSX_AUTHOR_CODE_CollectionClose

   //}}
}

//------------------------------------------------------------------------------

Customer& CollCust::CollectionItem(LSXString Index, LSUSHORT& Found)
{
   // This method is called if an item in the collection is accessed using
   // an index (i.e. theCollect("Item1") ) and should return the item at the
   // specified index.

   // In the event that the index is invalid or the item is otherwise not accessible,
   // the Found argument should be set to 0.

   //{{LSX_AUTHOR_CODE_CollectionItem

   LSPTR(Customer) NextCustomer;
   LSPTR(Customer) theCustomer;

   Found = 0;

   //   We are setting this up so that the collection is indexed by the
   //   Customer Number property.  In a big collection, it would be
   //   more efficient to use a data structure like a binary tree, which
   //   supports searching by keyword.  Here, we are potentially iterating
   //   through the entire collection to find an item.

   NextCustomer = CustomerList;
   while (NextCustomer != LSNULL && Found == 0)
   {
      if (Index == NextCustomer->GetAcctNumber())
      {
         Found = 1;
         theCustomer = NextCustomer;
      }

      NextCustomer = (LSPTR(Customer))(LSPTR(LSXBase)) NextCustomer->GetNextPtr();
   }

   return *theCustomer;

   //}}
}

/*******************************************************************************
 *
 * Method Definitions for methods that are exposed to LotusScript
 *
 *******************************************************************************/
void CollCust::CloseCustomers()
{
   //{{LSX_AUTHOR_CODE_Method_CloseCustomers

   LSPTR(Customer)      pCustomer=LSNULL;
   LSPTR(Customer)      pNextCust=LSNULL;

   m_CurrCustomer=LSNULL;
   if (CustomerList)
   {
      // We have an outstanding AddRef on each Customer object from when it was
      // created in CreateNewCustomer.  We need to pCustomer->DropRef(); on each

      pCustomer=CustomerList;
      while (pCustomer)
      {
         pNextCust = (LSPTR(Customer))&pCustomer->GetNext();
         pCustomer->DropRef();
         pCustomer = pNextCust;
      }

      LSXDeleteList(CustomerList);
      CustomerList = LSNULL;
   }

   alreadyconnected=LSFALSE;

   //}}
}
// -----------------------------------------------------------------------------
Customer& CollCust::GetFirstCustomer()
{
   //{{LSX_AUTHOR_CODE_Method_GetFirstCustomer

   if (alreadyconnected)
   {
      m_CurrCustIndex=1;
      m_CurrCustomer = CustomerList;
   }
   else
      LSXRaiseError(ERR_CUSTOMER_NOT_CONNECTED);

   return *m_CurrCustomer;

   //}}
}
// -----------------------------------------------------------------------------
Customer& CollCust::GetNextCustomer()
{
   //{{LSX_AUTHOR_CODE_Method_GetNextCustomer

   if (alreadyconnected == LSTRUE)
   {
      if ((m_CurrCustIndex + 1) <= m_NumCustomers)
      {
         m_CurrCustIndex++;

         m_CurrCustomer = (LSPTR(Customer))&(m_CurrCustomer)->GetNext();

      }
   }
   else
      LSXRaiseError(ERR_CUSTOMER_NOT_CONNECTED);

   return *m_CurrCustomer;

   //}}
}
// -----------------------------------------------------------------------------
Customer& CollCust::GetPrevCustomer()
{
   //{{LSX_AUTHOR_CODE_Method_GetPrevCustomer

   if (alreadyconnected == LSTRUE)
   {
      if ( m_CurrCustIndex - 1 > 0)
      {
         m_CurrCustIndex--;

         m_CurrCustomer = (LSPTR(Customer))&(m_CurrCustomer)->GetPrev();

      }
   }
   else
      LSXRaiseError(ERR_CUSTOMER_NOT_CONNECTED);

   return *m_CurrCustomer;

   //}}
}
// -----------------------------------------------------------------------------
LSSSHORT CollCust::OpenCustomers(LSXString& FileName)
{
   //{{LSX_AUTHOR_CODE_Method_OpenCustomers


   LSBOOL      IsConnected = LSTRUE;
   LSSSHORT    len=0;
   LSSSHORT    i=0;
   LSBOOL      recordRead;
   FileRecord  buffer;

   if (alreadyconnected == LSTRUE)
      return IsConnected;

   // Open the file

   // Not using the LS File Manager because I prefer the fgetc
   // functionality over the LS Read API.

#if !defined (OS400)
   hfile = fopen(FileName, "r");
#else
   // On OS400 we assume the text file was written on a PC and moved to AS/400
   // However, opening without "rb" results in an automatic conversion to EBCDIC
   // which will cause problems later on for fgetc and other operators on this file.
   // If the file is in EBCDIC, user should do a translation to ASCII when needed.

   hfile = fopen(FileName, "rb");
#endif

   if (hfile == LSNULL)   //   file open ?
   {
      IsConnected = LSFALSE;   //   set return value to FAIL
      LSXRaiseError(ERR_CUSTOMER_FILE_OPEN);
      return IsConnected;
   }

   memset(&buffer, 0x00, sizeof(FileRecord));
   recordRead = ReadOneRecord(&buffer);
   if (recordRead == LSFALSE)
   {
      IsConnected = LSFALSE;   //   set return value to FAIL
      fclose(hfile);
      this->LSXRaiseError(ERR_CUSTOMER_FILE_NO_DATA);
      return IsConnected;
   }

   while (recordRead != LSFALSE)   //   got one ?
   {
      i++;   //   count it
      CreateNewCustomer(&buffer);
      memset(&buffer, 0x00, sizeof(FileRecord));
      recordRead = ReadOneRecord(&buffer);
   }
   m_NumCustomers = i;

   fclose(hfile);

   //   set up the initial item values.
   m_CurrCustIndex= 1;
   m_CurrCustomer = CustomerList;

     alreadyconnected = LSTRUE;

   return IsConnected;

   //}}
}
/*******************************************************************************
 *
 * Internal Method Definitions
 *
 *******************************************************************************/
//{{LSX_AUTHOR_CODE_Internal_Methods

LSBOOL CollCust::ReadOneRecord(LSPTR(FileRecord) fr)
{
   LSSINT      c;
   LSPLTCHAR   buff[LSX_MAX_BUFF_LEN];
   LSSSHORT    i=0;
   LSSSHORT    whichstr=0;

   c = fgetc(this->hfile);
   if (c != EOF)
   {
      while (c != '\n')
      {
         whichstr++;
         i=0;
#if !defined (OS400)
         while ((c != ',') && (c != '\n') && (i < LSX_MAX_BUFF_LEN -1) )
#else
         while ((c != ',') && (c != '\n') && (c != '\r') && (i < LSX_MAX_BUFF_LEN -1) )
#endif
         {
            buff[i] = c;
            c = fgetc(this->hfile);
            i++;
         }
         buff[i] = '\0';
         switch (whichstr)
         {
         case 1:
            strcpy(fr->custName, buff);
            break;
         case 2:
            strcpy(fr->custAddress, buff);
            break;
         case 3:
            strcpy(fr->custPhone, buff);
            break;
         case 4:
            strcpy(fr->custNumber, buff);
            break;
         default:
            assert (LSFALSE);
            break;
         }

         memset(buff, 0x00, sizeof(buff));

         //   if it isn't the end of line read next char
         if (c != '\n')
         {
            c = fgetc(this->hfile);
            //skip space after a comma
            if (c == ' ')
            {
               c = fgetc(this->hfile);
            }
         }
      }
   }
   else
      return LSFALSE;

   return LSTRUE;
}


void CollCust::CreateNewCustomer(LSPTR(FileRecord) filerecord)
{
   LSPTR(Customer)   pCustomer=LSNULL;

   pCustomer = new (LsiInst) Customer(this,
                             filerecord->custName, filerecord->custAddress,
                             filerecord->custPhone,filerecord->custNumber);

   pCustomer->AddRef();

}
//}}

