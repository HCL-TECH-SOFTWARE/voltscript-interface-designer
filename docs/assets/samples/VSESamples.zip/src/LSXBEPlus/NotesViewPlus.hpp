/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: NotesViewPlus.hpp

   Description:
      Class definition for scriptable "NotesViewPlus" object

\*==============================================================================*/
#if !defined (NOTESVIEWPLUS_HPP)
#define NOTESVIEWPLUS_HPP

//{{LSX_AUTHOR_CODE_Include1
//}}

#include "lsxapplx.h"
#include "lsxbase.hpp"
#include "lsxsess.hpp"

class NotesViewPlus;

typedef LSXObjectArray<NotesViewPlus, CLSXBEPLUS_NOTESVIEWPLUS_ID> NotesViewPlusArray;

//{{LSX_AUTHOR_CODE_Include2
#include "NotesDbPlus.hpp"
//}}

// forward references to other classes
class NotesDbPlus;
typedef LSXObjectArray<NotesDbPlus, CLSXBEPLUS_NOTESDBPLUS_ID> NotesDbPlusArray;

class NotesViewPlus : public LSXBase
//{{LSX_AUTHOR_CODE_Additional_Base_Classes
//}}
{
   protected:

      //The actual Notes back end class that we're inheriting from.
      NotesView m_BaseNotesView;

      // Data members exposed to LotusScript via Get/Set Prop (access functions inlined below)


      //{{LSX_AUTHOR_CODE_Protected_Internal
      //}}

   private:

      //{{LSX_AUTHOR_CODE_Private_Internal
      LSBOOL ContainedByNotesDBPlus;
      //}}

      // These are private because they are unimplemented and we need to prevent
      // the compiler from creating default versions.
      NotesViewPlus & operator = (NotesViewPlus&);
      NotesViewPlus (const NotesViewPlus&);
      NotesViewPlus();

   public:

      // This constructor is called when the script "new"s one or calls
      // a function like "CreateNotesViewPlus" on the container class.
      NotesViewPlus( LSPTR(LSXLsiSession) pContainer, NotesView& BaseNotesView );

      // This constructor is used by a derived class to initialize its parent
      NotesViewPlus(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer, NotesView& BaseNotesView  );

      virtual ~NotesViewPlus();


      // Methods exposed to LotusScript
      LSSLONG GetDocPosition ( NotesDocument& theDoc  );

      // Event-Raising methods

      
      // Helper functions - not exposed to LotusScript

      LSPTR(LSXLsiSession) LSXGetSession() const
      { 
         return ((LSPTR(LSXLsiSession)) pContainerObject)->LSXGetSession(); 
      }

      //{{LSX_AUTHOR_CODE_Public_Internal (not exposed to LotusScript)
      NotesViewPlus( LSPTR(NotesDbPlus) pContainer, NotesView& BaseNotesView);
      //}}

      // Low-level calls defined in iNotesViewPlus.CPP.
      virtual LSSTATUS LSXDispatchMethod(PLSADTMSGMETHOD args);
      virtual LSSTATUS LSXGetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);
      virtual LSSTATUS LSXSetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);


      // Property Gets and Sets for data members exposed to LotusScript


      //{{LSX_AUTHOR_CODE_Inlines
      //}}
};

//{{LSX_AUTHOR_CODE_Other
//}}

#endif   //   #if !defined (NOTESVIEWPLUS_HPP)

