/*========================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: guidfile.h

   Description:
      This file contains YOUR GUID for use in your LSX.

      After acquiring the GUID, you should identify its constituent
      components as shown below.

\*========================================================================*/

#if !defined (GUIDFILE_H)
#define GUIDFILE_H

/*
   Suppose you have  59E7A721-D5A4-11D2-B0A2-00104B11BE27  as your GUID
*/

/* ---------------------------------------------------------------------------
   GUIDs - Globally Unique IDs
   --------------------------------------------------------------------------

   NOTE: If you use the macro

         DEFINE_GUID(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8)

         supplied by the OLE header files, the mapping of parameters to
         ordering in the GUID string you see in the Registry is:

            l        w1   w2   b1b2 b3b4b5b6b7b8
            |        |    |    | |  | | | | | |
            59E7A721-D5A4-11D2-B0A2-00104B11BE27

   ---------------------------------------------------------------------------
*/
/* ---------------------------------------------------------------------------
   #defines for the pieces of a GUID
*/

// your GUID is 59E7A721-D5A4-11D2-B0A2-00104B11BE27

#define LSX_YOUR_GUID_BASE_UL     ((unsigned long) 0x59E70000)
#define LSX_YOUR_GUID_OFFSET_US   0xA721

#define LSX_GUID_D2  0xD5A4
#define LSX_GUID_D3  0x11D2
#define LSX_GUID_D41 0xB0
#define LSX_GUID_D42 0xA2
#define LSX_GUID_D43 0x00
#define LSX_GUID_D44 0x10
#define LSX_GUID_D45 0x4B
#define LSX_GUID_D46 0x11
#define LSX_GUID_D47 0xBE
#define LSX_GUID_D48 0x27

//
// Note: these all refer to YOUR GUID base - which MUST not conflict !!!
//                        ********               ********

// even though we don't expose the Session class we still need a GUID for it

DEFINE_LSX_GUID(c_Session, LSX_ID_LSXBase + CLSXBEPLUS_SESSION_ID);
DEFINE_LSX_GUID(c_NotesDbPlus, LSX_ID_LSXBase + CLSXBEPLUS_NOTESDBPLUS_ID);
DEFINE_LSX_GUID(c_NotesViewPlus, LSX_ID_LSXBase + CLSXBEPLUS_NOTESVIEWPLUS_ID);

#endif   //   #if !defined (GUIDFILE_H)