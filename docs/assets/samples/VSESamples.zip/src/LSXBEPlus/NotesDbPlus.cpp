/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: NotesDbPlus.cpp

   Description:
      Implementation of methods for the scriptable "NotesDbPlus" object

\*============================================================================*/

//{{LSX_AUTHOR_CODE_Include_1
//}}

#include "NotesDbPlus.hpp"

// includes for the objects defined in your LSX
#include "NotesViewPlus.hpp"

//{{LSX_AUTHOR_CODE_Include_2
//}}

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 * Constructors/Destructors
 *
 ******************************************************************************/
// This constructor is called when the script 'new's one or calls
// CreateNotesDbPlus on the container class.

NotesDbPlus:: NotesDbPlus( LSPTR(LSXLsiSession) pContainer, NotesDatabase& BaseNotesDb)
   : LSXBase((LSPLTSTR)"NotesDbPlus", pContainer->LSXGetInstance(), CLSXBEPLUS_NOTESDBPLUS_ID, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init1
   //}}
   m_BaseNotesDatabase(BaseNotesDb),
   m_DefaultView()
   //{{LSX_AUTHOR_CODE_Internal_Member_Init1
   ,NotesViewPlusList(LSNULL)
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor1

   // Initialize the m_DefaultView property
   NotesViewArray ViewArray = 
      m_BaseNotesDatabase.GetProp(CNOTES_DBPROP_VIEWS).getObjectArray(CNOTES_CLASS_VIEW);

   LSULONG i = 0;
   LSBOOL Found = LSFALSE;
   while (i < ViewArray.getElemCount() && ! Found)
   {
      // Each element in the ViewArray is an ILsiADTControl, convert it to 
      // a NotesView so we can more easily access its properties
      NotesView view = NotesView(ViewArray.getElemAt(i), CNOTES_CLASS_VIEW, LsiInst);

      if (view.GetProp(CNOTES_VPROP_ISDEFAULT).getBool() == LSXTrue)
      {
         m_DefaultView = view;
         Found = LSTRUE;
      }
      i++;
   }
  
   //}}

}

// ------------------------------------------------------------------------------

// This version of the constructor is called by a derived class for its 
// constructor initialization.

NotesDbPlus:: NotesDbPlus(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer, NotesDatabase& BaseNotesDb )
   : LSXBase((LSPLTSTR)"NotesDbPlus", pContainer->LSXGetInstance(), classId, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init2
   //}}
   m_BaseNotesDatabase(BaseNotesDb),
   m_DefaultView()
   //{{LSX_AUTHOR_CODE_Internal_Member_Init2
   ,NotesViewPlusList(LSNULL)
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor2
   //}}

}

//------------------------------------------------------------------------------
//{{LSX_AUTHOR_CODE_Additional_Constructors
//}}
//------------------------------------------------------------------------------

NotesDbPlus:: ~NotesDbPlus()
{
   //{{LSX_AUTHOR_CODE_Destructor

   // See important comments about this in the GetViewPlus method.
   LSXDeleteList(NotesViewPlusList);
   //}}

   

}

/*******************************************************************************
 *
 * Method Definitions for methods that are exposed to LotusScript
 *
 *******************************************************************************/
LSFLOAT8 NotesDbPlus::AverageDocSize()
{
   //{{LSX_AUTHOR_CODE_Method_AverageDocSize

   LSSLONG TotSize = 0;
   LSSLONG CurrSize = 0;

   NotesDocumentCollection DocColl = 
      m_BaseNotesDatabase.GetProp(CNOTES_DBPROP_FINDALLDOCS).getForeignObject();

   LSSLONG count = DocColl.GetProp(CNOTES_DCPROP_NUMDOCS).getLong();

   NotesDocument CurrDoc = 
      DocColl.CallFunction(CNOTES_DCMETH_GETFIRST).getForeignObject();
   
   try
   {
      CurrSize = CurrDoc.GetProp(CNOTES_NPROP_SIZE).getLong();
   }
   catch(...)
   {
      LsiInst->RaiseError(LSTID_CURRENT, 30000,
                        "GetProp on Size does not work with lsxbe 4.5.  Refer to the documentation section entitled 'Accessing the Domino Objects (Notes back-end classes)' for a work-around.", LSI_REGNAME_PLATFORM);
   }

   while ( ! CurrDoc.IsNull())
   {
      TotSize+=CurrSize;
      
      // Initialize that argument array like this so that arguments can be passed to the
      // constructor.
      LSXValue Args[] = 
      {
         LSXValue(CurrDoc, LsiInst),
         // additional argument would go here
      };

      CurrDoc = DocColl.CallFunction(CNOTES_DCMETH_GETNEXT, Args).getForeignObject();
      if (! CurrDoc.IsNull())
         CurrSize = CurrDoc.GetProp(CNOTES_NPROP_SIZE).getLong();
   }

   return TotSize/count;

   //}}
}
// -----------------------------------------------------------------------------
NotesDocument NotesDbPlus::GetNewestDoc()
{
   //{{LSX_AUTHOR_CODE_Method_GetNewestDoc

   NotesDocument NewestDoc;

   LSXDate NewestDate(LsiInst);
   LSXDate CurrDate(LsiInst);

   NotesDocumentCollection DocColl = 
      m_BaseNotesDatabase.GetProp(CNOTES_DBPROP_FINDALLDOCS).getForeignObject();

   NotesDocument CurrDoc = 
      DocColl.CallFunction(CNOTES_DCMETH_GETFIRST).getForeignObject();

   CurrDate = CurrDoc.GetProp(CNOTES_NPROP_CREATED).getDate();
   NewestDate = CurrDate;

   while ( ! CurrDoc.IsNull())
   {
      if (CurrDate > NewestDate)
      {
         NewestDate = CurrDate;
         NewestDoc = CurrDoc;
      }

      // Initialize that argument array like this so that arguments can be passed to the
      // constructor.
      LSXValue Args[] = 
      {
         LSXValue(CurrDoc, LsiInst),
         // additional argument would go here
      };

      CurrDoc = DocColl.CallFunction(CNOTES_DCMETH_GETNEXT, Args).getForeignObject();
      if (! CurrDoc.IsNull())
         CurrDate = CurrDoc.GetProp(CNOTES_NPROP_CREATED).getDate();
   }

   return NewestDoc;

   //}}
}
// -----------------------------------------------------------------------------
LSXString NotesDbPlus::GetViewNames()
{
   //{{LSX_AUTHOR_CODE_Method_GetViewNames

   LSXString RetVal;

   LSXAdtCtlArray ViewArray = 
      m_BaseNotesDatabase.GetProp(CNOTES_DBPROP_VIEWS).getObjectArray(CNOTES_CLASS_VIEW);

   for (LSULONG i = 0; i < ViewArray.getElemCount(); i++)
   {
      // Each element in the ViewArray is an ILsiADTControl, convert it to 
      // a NotesView so we can more easily access its properties
      NotesView view = NotesView(ViewArray.getElemAt(i), CNOTES_CLASS_VIEW, LsiInst);

      RetVal += view.GetProp(CNOTES_VPROP_NAME).getString();
      RetVal += "\n";
   }

   return RetVal;

   //}}
}
// -----------------------------------------------------------------------------
NotesViewPlus& NotesDbPlus::GetViewPlus(LSXString ViewName)
{
   //{{LSX_AUTHOR_CODE_Method_GetViewPlus

   // This method is like the GetView method of NotesDatabase
   // except that it returns a NotesViewPlus instead of just
   // a NotesView.

   // Initialize that argument array like this so that arguments can be passed to the
   // constructor.
   LSXValue Args[] = 
   {
      LSXValue(ViewName, LsiInst),
      // additional argument would go here
   };

   NotesView NotesVw = 
      m_BaseNotesDatabase.CallFunction(CNOTES_DBMETH_FINDVIEW, Args).getForeignObject();

   // When we specified the NotesView class in the Wizard, we declared the container
   // class to be "default" (in fact, the Session object).  We didn't specify the
   // container as NotesDbPlus because we wanted the script writer to be able to 
   // access NotesViewPlus objects without needing a NotesDbPlus object. 
   
   // The generated constructor contains code (in the base class) to add the new 
   // object to the Session's list of contained objects.  However, in this case
   // where the NotesDbPlus object is creating the NotesViewPlus object, we would
   // really have this be the container object.  
   
   // Since the code was not generated that way, we need to add a new constructor 
   // to the NotesViewPlus class which will add itself to the right list, create 
   // an internal data member in this class to hold the list (don't forget to 
   // initialize it in the constructor) and create functions for manipulating
   // this list that can be called by the NotesViewPlus class.
   
   // We also need to add code to the NotesViewPlus' destructor to remove itself
   // from this list when the object is destroyed, and code to this objects
   // destructor to destroy the list and it's elements when it is destroyed.

   LSPTR(NotesViewPlus) NotesVwPlus = new (LsiInst) NotesViewPlus(this, NotesVw);

   return *NotesVwPlus;

   //}}
}
// -----------------------------------------------------------------------------
LSXString NotesDbPlus::ListManagers()
{
   //{{LSX_AUTHOR_CODE_Method_ListManagers

   // Returns the list of readers in the view in list format instead of
   // as a string array.

   LSXString ManagersList;

   LSXStringArray ManagersArray = 
      m_BaseNotesDatabase.GetProp(CNOTES_DBPROP_DBMGRS).getStringArray();

   for (LSULONG l = 0; l < ManagersArray.getElemCount(); l++)
   {
      ManagersList += ManagersArray[l];
      ManagersList += LIT_STR("\n");
   }

   return ManagersList;

   //}}
}
// -----------------------------------------------------------------------------
void NotesDbPlus::SetTitleByMethod(LSXString NewTitle)
{
   //{{LSX_AUTHOR_CODE_Method_SetTitleByMethod

   // This method sets the document title by accessing the Title
   // property of the base NotesDatabase class.

   LSXValue value(NewTitle, LsiInst);
   m_BaseNotesDatabase.SetProp(CNOTES_DBPROP_DBTITLE, value);

   //}}
}
/*******************************************************************************
 *
 * Internal Method Definitions
 *
 *******************************************************************************/
//{{LSX_AUTHOR_CODE_Internal_Methods
//}}

