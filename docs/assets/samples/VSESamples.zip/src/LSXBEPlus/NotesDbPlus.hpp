/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: NotesDbPlus.hpp

   Description:
      Class definition for scriptable "NotesDbPlus" object

\*==============================================================================*/
#if !defined (NOTESDBPLUS_HPP)
#define NOTESDBPLUS_HPP

//{{LSX_AUTHOR_CODE_Include1
//}}

#include "lsxapplx.h"
#include "lsxbase.hpp"
#include "lsxsess.hpp"

class NotesDbPlus;

typedef LSXObjectArray<NotesDbPlus, CLSXBEPLUS_NOTESDBPLUS_ID> NotesDbPlusArray;

//{{LSX_AUTHOR_CODE_Include2
#include "NotesViewPlus.hpp"
//}}

// forward references to other classes
class NotesViewPlus;
typedef LSXObjectArray<NotesViewPlus, CLSXBEPLUS_NOTESVIEWPLUS_ID> NotesViewPlusArray;

class NotesDbPlus : public LSXBase
//{{LSX_AUTHOR_CODE_Additional_Base_Classes
//}}
{
   protected:

      //The actual Notes back end class that we're inheriting from.
      NotesDatabase m_BaseNotesDatabase;

      // Data members exposed to LotusScript via Get/Set Prop (access functions inlined below)
      NotesView m_DefaultView;

      //{{LSX_AUTHOR_CODE_Protected_Internal
      //}}

   private:

      //{{LSX_AUTHOR_CODE_Private_Internal
      LSPTR(NotesViewPlus) NotesViewPlusList;
      //}}

      // These are private because they are unimplemented and we need to prevent
      // the compiler from creating default versions.
      NotesDbPlus & operator = (NotesDbPlus&);
      NotesDbPlus (const NotesDbPlus&);
      NotesDbPlus();

   public:

      // This constructor is called when the script "new"s one or calls
      // a function like "CreateNotesDbPlus" on the container class.
      NotesDbPlus( LSPTR(LSXLsiSession) pContainer, NotesDatabase& BaseNotesDb );

      // This constructor is used by a derived class to initialize its parent
      NotesDbPlus(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer, NotesDatabase& BaseNotesDb  );

      virtual ~NotesDbPlus();


      // Methods exposed to LotusScript
      LSFLOAT8 AverageDocSize (  );
      NotesDocument GetNewestDoc (  );
      LSXString GetViewNames (  );
      NotesViewPlus& GetViewPlus ( LSXString ViewName  );
      LSXString ListManagers (  );
      void SetTitleByMethod ( LSXString NewTitle  );

      // Event-Raising methods

      
      // Helper functions - not exposed to LotusScript

      LSPTR(LSXLsiSession) LSXGetSession() const
      { 
         return ((LSPTR(LSXLsiSession)) pContainerObject)->LSXGetSession(); 
      }

      //{{LSX_AUTHOR_CODE_Public_Internal (not exposed to LotusScript)

      void AddToNotesViewPlusList(LSPTR(NotesViewPlus) c)
      {
         LSXAddToList((LSPTR(LSXBase))c, (LSPTR(LSPTR(LSXBase)))&NotesViewPlusList);
      }

      void RemoveFromNotesViewPlusList(LSPTR(NotesViewPlus) c)
      {
         LSXRemoveFromList((LSPTR(LSXBase))c,(LSPTR(LSPTR(LSXBase)))&NotesViewPlusList);
      }

      //}}

      // Low-level calls defined in iNotesDbPlus.CPP.
      virtual LSSTATUS LSXDispatchMethod(PLSADTMSGMETHOD args);
      virtual LSSTATUS LSXGetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);
      virtual LSSTATUS LSXSetProp( PLSADTINSTDESC pinstdesc, PLSADTMSGPROP param);


      // Property Gets and Sets for data members exposed to LotusScript
      inline NotesView& GetDefaultView()  
      {
         //{{LSX_AUTHOR_CODE_PropertyGet_DefaultView
         //}}

         return m_DefaultView;
      }


      //{{LSX_AUTHOR_CODE_Inlines
      //}}
};

//{{LSX_AUTHOR_CODE_Other
//}}

#endif   //   #if !defined (NOTESDBPLUS_HPP)

