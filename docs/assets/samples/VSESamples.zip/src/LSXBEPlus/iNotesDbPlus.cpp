/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: iNotesDbPlus.cpp

   Description:
      Class methods to support LSX architecture.

\*============================================================================*/

#include "NotesDbPlus.hpp"

#include "NotesViewPlus.hpp"

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 *   Expanded class support (only if this class is expanded)
 *
 *******************************************************************************/

/*******************************************************************************
 *
 *   Containment support (only if this class is a container)
 *
 *******************************************************************************/

/*******************************************************************************
 *
 *   Collection support (only if this class is a collection)
 *
 *******************************************************************************/

/*******************************************************************************
 *
 *   Property Dispatching
 *
 *******************************************************************************/

LSSTATUS NotesDbPlus:: LSXGetProp(PLSADTINSTDESC pInstDesc, PLSADTMSGPROP param)
{
   LSSTATUS     stat = LSX_OK;
   LSADTPROPID  id   = param->idProp;

   LSXValue Val(param->valProp, LsiInst);

   switch (id)
   {
   case CLSXBEPLUS_NOTESDBPLUSPROP_DEFAULTVIEW:
      Val.set(GetDefaultView());
      break;

   default:
      m_BaseNotesDatabase.GetProp(param);
      break;
   }

   return stat;
}

//------------------------------------------------------------------------------

LSSTATUS NotesDbPlus:: LSXSetProp(PLSADTINSTDESC pInstDesc, PLSADTMSGPROP param)
{
   LSSTATUS     stat = LSX_OK;
   LSADTPROPID  id   = param->idProp;

   LSXValue Val(param->valProp, LsiInst);

   switch (id)
   {
   case CLSXBEPLUS_NOTESDBPLUSPROP_DEFAULTVIEW:

      break;

   default:
      m_BaseNotesDatabase.SetProp(param);
      break;
   }

   return stat;
}

/*******************************************************************************
 *
 *   Method Dispatching and Argument Parsing
 *
 *******************************************************************************/
LSSTATUS NotesDbPlus:: LSXDispatchMethod(PLSADTMSGMETHOD args)
{
   LSSTATUS stat = LSX_OK;

   // using the given method id, call the appropriate class method

   switch (args->idMeth)
   {
   case CLSXBEPLUS_NOTESDBPLUSMETHOD_AVERAGEDOCSIZE:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      
      //Execute the method
      LSFLOAT8 RetVal = AverageDocSize();

      //Set return value
      ArgList.setRetVal(RetVal);
      
      }
      break;

   case CLSXBEPLUS_NOTESDBPLUSMETHOD_GETNEWESTDOC:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      
      //Execute the method
      NotesDocument RetVal = GetNewestDoc();

      //Set return value
      ArgList.setRetVal(RetVal);
      
      }
      break;

   case CLSXBEPLUS_NOTESDBPLUSMETHOD_GETVIEWNAMES:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      
      //Execute the method
      LSXString RetVal = GetViewNames();

      //Set return value
      ArgList.setRetVal(RetVal);
      
      }
      break;

   case CLSXBEPLUS_NOTESDBPLUSMETHOD_GETVIEWPLUS:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      //Extract the arguments
      LSXString ViewName =  ArgList.getArg(1).getString();

      
      //Execute the method
      NotesViewPlus& RetVal = GetViewPlus(ViewName);

      //Set return value
      ArgList.setRetVal(RetVal);
      
      }
      break;

   case CLSXBEPLUS_NOTESDBPLUSMETHOD_LISTMANAGERS:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, FUNCTION, LsiInst);

      
      
      //Execute the method
      LSXString RetVal = ListManagers();

      //Set return value
      ArgList.setRetVal(RetVal);
      
      }
      break;

   case CLSXBEPLUS_NOTESDBPLUSMETHOD_SETTITLEBYMETHOD:
      { //Force a new scope so we can repeat variable names in each case

      //Initialize the args object
      LSXArgs ArgList(args, SUB, LsiInst);

      
      //Extract the arguments
      LSXString NewTitle =  ArgList.getArg(1).getString();

      
      //Execute the method
      SetTitleByMethod(NewTitle);
      
      }
      break;


   // list any other methods that you are exposing to the users of your LSX

   default:
      /*
      ** Either we have been passed
      **    (i) a bogus method id from LS, or,
      **   (ii) the method id of one of the parent class's methods (ie. this
      **        class is derived from a parent class).
      **
      ** If situation (i) then we need to determine why we have been passed
      ** the bad method id and fix the problem. This could occur if we changed
      ** the id's that we register with LS and did not tell LS at registration
      ** time that they had changed - by updating the version number.
      ** If you have changed the id's  you MUST recompile the script.
      **
      ** In that case, we should fail, thus:

         stat = LSI_RTE_SubOrFunctionNotDefined;
         assert (LSFALSE);

      ** If situation (ii) then we need to pass the method id on to the
      ** parent class dispatch method.  If the parent class is one of
      ** your own classes, you can code the call thus:

         stat = LSXBase::LSXDispatchMethod(args);

      ** If the parent class is one of the Notes back-end classes, then
      ** we need to pass the method id and args block on to his dispatch
      ** method. ie. pretend we are LotusScript.

         stat = pADT->ClassControl(this->LSXGetInstance(),
                                  LSI_ADTMSG_METHOD,
                                  this->LSXGetADTInstDesc(),
                                  (LSPTR(void))args);

      ** In order to use this call successfully, we will need to have cached
      ** a pointer to the "real" corresponding Notes back-end object.
      ** For an example of how this is done, see the LSXBEPlus sample
      ** (NotesDbPlus.CPP & iNotesDbPlus.CPP)
      */

      m_BaseNotesDatabase.CallMethod(args);
      break;
   }

   return stat;
}
/*******************************************************************************
 *
 *   Event Raising Method Definitions
 *
 *******************************************************************************/

