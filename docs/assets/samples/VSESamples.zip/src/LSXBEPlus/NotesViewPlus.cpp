/*=============================================================================*\

   Copyright HCL America, Inc. 1999, 2023

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   File: NotesViewPlus.cpp

   Description:
      Implementation of methods for the scriptable "NotesViewPlus" object

\*============================================================================*/

//{{LSX_AUTHOR_CODE_Include_1
//}}

#include "NotesViewPlus.hpp"

// includes for the objects defined in your LSX
#include "NotesDbPlus.hpp"

//{{LSX_AUTHOR_CODE_Include_2
//}}

#if defined (OS390) || (defined (OS400) && defined(__STRING_CODE_SET__))
/* This must be the last #include */
#include <_Ascii_a.h>
#endif

/*******************************************************************************
 *
 * Constructors/Destructors
 *
 ******************************************************************************/
// This constructor is called when the script 'new's one or calls
// CreateNotesViewPlus on the container class.

NotesViewPlus:: NotesViewPlus( LSPTR(LSXLsiSession) pContainer, NotesView& BaseNotesView)
   : LSXBase((LSPLTSTR)"NotesViewPlus", pContainer->LSXGetInstance(), CLSXBEPLUS_NOTESVIEWPLUS_ID, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init1
   //}}
   m_BaseNotesView(BaseNotesView)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init1
   ,ContainedByNotesDBPlus(LSFALSE)
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor1
   //}}

}

// ------------------------------------------------------------------------------

// This version of the constructor is called by a derived class for its 
// constructor initialization.

NotesViewPlus:: NotesViewPlus(LSUSHORT classId, LSPTR(LSXLsiSession) pContainer, NotesView& BaseNotesView )
   : LSXBase((LSPLTSTR)"NotesViewPlus", pContainer->LSXGetInstance(), classId, pContainer), 
   //{{LSX_AUTHOR_CODE_Additional_Base_Class_Init2
   //}}
   m_BaseNotesView(BaseNotesView)
   //{{LSX_AUTHOR_CODE_Internal_Member_Init2
   ,ContainedByNotesDBPlus(LSFALSE)
   //}}
{
   //{{LSX_AUTHOR_CODE_Constructor2
   //}}

}

//------------------------------------------------------------------------------
//{{LSX_AUTHOR_CODE_Additional_Constructors

//This constructor is used by the GetViewPlus method of the NotesDbPlus class

NotesViewPlus:: NotesViewPlus( LSPTR(NotesDbPlus) pContainer, NotesView& BaseNotesView)
   : LSXBase((LSPLTSTR)"NotesViewPlus", pContainer->LSXGetInstance(), CLSXBEPLUS_NOTESVIEWPLUS_ID, pContainer), 
   m_BaseNotesView(BaseNotesView)
{
   pContainer->AddToNotesViewPlusList(this);
   ContainedByNotesDBPlus = LSTRUE;
}

//}}
//------------------------------------------------------------------------------

NotesViewPlus:: ~NotesViewPlus()
{
   //{{LSX_AUTHOR_CODE_Destructor

    if (ContainedByNotesDBPlus && pContainerObject)
      ((LSPTR(NotesDbPlus))pContainerObject)->RemoveFromNotesViewPlusList(this);

   //}}

   

}

/*******************************************************************************
 *
 * Method Definitions for methods that are exposed to LotusScript
 *
 *******************************************************************************/
LSSLONG NotesViewPlus::GetDocPosition(NotesDocument& theDoc)
{
   //{{LSX_AUTHOR_CODE_Method_GetDocPosition

   //Returns the position in the view of the specified document. 0 if not found.

   LSSLONG pos = 0;
   LSBOOL Found = LSFALSE;
   NotesDocument CurrDoc = m_BaseNotesView.CallFunction(CNOTES_VMETH_GETFIRSTDOC).getForeignObject();

   while ( ! CurrDoc.IsNull() && !Found)
   {
      pos++;

      if (theDoc == CurrDoc)
         Found = LSTRUE;

      //Initialize that argument array like this so that arguments can be passed to the
      //constructor.
      LSXValue Args[] = 
      {
         LSXValue(CurrDoc, LsiInst),
         //additional argument would go here
      };

      CurrDoc = m_BaseNotesView.CallFunction(CNOTES_VMETH_GETNEXTDOC, Args).getForeignObject();
   }

   if (!Found)
      return 0;
   else
      return pos;

   //}}
}
/*******************************************************************************
 *
 * Internal Method Definitions
 *
 *******************************************************************************/
//{{LSX_AUTHOR_CODE_Internal_Methods
//}}

