# VSESamples
This archive contains VoltScript Extension (VSE) samples from the original LSXToolkit project. They have been updated using VoltScript Interface Designer (VSID) and build files have been added, allowing the VSE's to be built and run on modern operating systems.

Extract this archive into the same directory as a generated VSE from VSID. These VSE's use the same common source files as other VSE's, and have additional directories for their specific source files. CMake files are in the source directories for each VSE. Build scripts are provided for these VSE's as a convenience.

These VSE's were designed for Windows, and Linux versions are only available for some of them.

A sample seti.ini, which VoltScript reads to discover paths to VSE's at runtime, is provided in the file `seti-sample.ini`.

# Customer
Features a simple Customer class containing contact information, and a CustomerColl class which contains a collection of these Customers. The CustomerColl.OpenCustomers method loads a CSV containing Customer objects. A test script is provided, and can be run through the build scripts with the flag ``--test`` in addition to ``--release`` or ``--debug``.

This VSE has Linux support.

# DataTypes
An example of the data types supported by VSID. A test script is provided, and can be run through the build scripts with the flag ``--test`` in addition to ``--release`` or ``--debug``.

This VSE has Linux support.

# LSXBEPlus
Example of extending the LSXBE library.

This VSE is only available on Windows, and will not compile on Linux.

# SystemCheck
Uses Windows system calls to fetch and present information about the host system the VSE is running on.

This VSE is only available on Windows, and will not compile on Linux.
